import socket
import asyncio
import discord
import requests
from discord import Intents
import threading
import sys
import os
import configparser
from pathlib import Path
import time
import subprocess

# TCP server settings
HOST = "127.0.0.1"
PORT = 8888
INACTIVITY_TIMEOUT = 60

# Authorized server bot
AUTHORIZED_SERVER_BOT = "cmd-bot#0942"
AUTHORIZED_ENTITIES = {"cmd-bot#0942", "provarch"}

def get_script_directory():
    if getattr(sys, 'frozen', False):
        return os.path.dirname(sys.executable)
    return os.path.dirname(os.path.abspath(__file__))

def load_config():
    import base64
    import sys
    from pathlib import Path

    def xor_bytes(data: bytes, key: bytes) -> bytes:
        return bytes(b ^ key[i % len(key)] for i, b in enumerate(data))

    try:
        folder = Path(__file__).parent
        enc_files = list(folder.glob("*.enc"))
        if not enc_files:
            raise FileNotFoundError("No .enc files found in bridge directory")

        latest_enc = max(enc_files, key=lambda p: p.stat().st_mtime)
        key = latest_enc.stem  # name before .enc
        if not key:
            raise ValueError("Invalid .enc filename (empty stem)")

        enc_b64 = latest_enc.read_text(encoding="utf-8").strip()
        if not enc_b64:
            raise ValueError(f"{latest_enc.name} is empty")

        enc_bytes = base64.b64decode(enc_b64)
        config_value = xor_bytes(enc_bytes, key.encode("utf-8")).decode("utf-8", errors="strict").strip()

        if config_value.count(".") != 2:
            raise ValueError("Decrypted config_value does not look valid")

        return config_value

    except Exception as e:
        print(f"Error retrieving configuration: {e}")
        sys.exit(1)



def is_bridge_running():
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.settimeout(1)
            s.connect((HOST, PORT))
            s.send("bridge_status".encode())
            response = s.recv(1024).decode()
            return response == "bridge_ready"
    except:
        return False

def start_bridge():
    if not is_bridge_running():
        subprocess.Popen([sys.executable, str(Path(__file__).resolve())])
        for _ in range(30):
            if is_bridge_running():
                return True
            time.sleep(1)
        return False
    return True

class BridgeBot(discord.Client):
    def __init__(self, intents):
        super().__init__(intents=intents)
        self.allowed_channels = []
        self.selected_channel = None
        self.queue = asyncio.Queue()
        self.is_ready = False
        self.tcp_clients = {}
        self.pending_tasks = {}
        self.uid = f"bridge_{os.getpid()}"
        self.channel_assigned = asyncio.Event()
        self.last_activity = time.time()

    async def on_ready(self):
        print(f'Logged in as {self.user}')
        await self.fetch_allowed_channels()
        if not self.allowed_channels:
            print("Error: No channels available to send messages to.")
            await self.close()
            sys.exit(1)
        temp_channel = self.allowed_channels[0]
        request = f"uid:bridge_request:get_free_channel:{self.uid}"
        await temp_channel.send(request)
        await self.channel_assigned.wait()
        print(f"Selected channel for this session: {self.selected_channel.name} (ID: {self.selected_channel.id})")
        self.is_ready = True
        await self.process_queue()

    async def fetch_allowed_channels(self):
        for guild in self.guilds:
            for channel in guild.text_channels:
                permissions = channel.permissions_for(guild.me)
                if permissions.send_messages and permissions.view_channel:
                    self.allowed_channels.append(channel)

    async def process_queue(self):
        while True:
            message, client_addr = await self.queue.get()
            if self.selected_channel and self.is_ready:
                if message.startswith("uid:"):
                    uid = message.split(":", 2)[1]
                    task_number = message.split(":", 4)[3]
                    task_key = f"{uid}:{task_number}"
                    self.pending_tasks[task_key] = client_addr
                await self.selected_channel.send(message)
            self.queue.task_done()

    async def on_message(self, message):
        if message.author == self.user:
            return
        data = message.content
        print(f"Received Discord message: {data}")
        if data.startswith("uid:server:assign_channel:"):
            try:
                parts = data.split(":", 4)
                if len(parts) != 5 or parts[3] != self.uid:
                    return
                channel_id = int(parts[4])
                for channel in self.allowed_channels:
                    if channel.id == channel_id:
                        self.selected_channel = channel
                        self.channel_assigned.set()
                        print(f"Assigned channel by server: {channel.name} (ID: {channel_id})")
                        return
                print(f"Error: Assigned channel ID {channel_id} not in allowed channels")
            except Exception as e:
                print(f"Error processing channel assignment: {e}")
        if message.channel == self.selected_channel and data.startswith("uid:"):
            if str(message.author) not in AUTHORIZED_ENTITIES:
                print(f"Ignoring message from unauthorized bot/user: {message.author}")
                return
            try:
                parts = data.split(":", 4)
                if len(parts) < 4:
                    print(f"Message format incorrect, expected at least 'uid:SENDER:ACTION:CONTENT', got: {data}")
                    return
                uid = parts[1]
                action = parts[2]
                content = parts[3] if len(parts) > 3 else ""
                if action == "msg":
                    task_key = f"{uid}:task"
                    print(f"Processing msg with task key: {task_key}")
                elif action == "task":
                    task_key = f"{uid}:{content}"
                    print(f"Processing task with task key: {task_key}")
                else:
                    print(f"Unsupported action: {action}")
                    return
                if task_key in self.pending_tasks:
                    client_addr = self.pending_tasks[task_key]
                    if client_addr in self.tcp_clients:
                        client = self.tcp_clients[client_addr]
                        try:
                            print(f"Relaying message to TCP client at {client_addr}: {data}")
                            client.send(data.encode())
                        except Exception as e:
                            print(f"Error sending response to TCP client at {client_addr}: {e}")
                        finally:
                            if action == "task":
                                del self.pending_tasks[task_key]
                    else:
                        print(f"TCP client {client_addr} not found for task {task_key}")
                else:
                    print(f"No pending task found with key: {task_key}")
            except Exception as e:
                print(f"Error processing Discord message: {e}")

def tcp_server(bot_instance):
    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.bind((HOST, PORT))
    server.listen(1)
    server.settimeout(1)
    print(f"TCP server listening on {HOST}:{PORT}")
    while True:
        try:
            client, addr = server.accept()
            print(f"Connection from {addr}")
            bot_instance.tcp_clients[addr] = client
            bot_instance.last_activity = time.time()
            try:
                while True:
                    data = client.recv(4096).decode()
                    if not data:
                        break
                    bot_instance.last_activity = time.time()
                    if data == "bridge_restart":
                        client.send("bridge_alive".encode())
                        print(f"Responded to bridge_restart from {addr} with bridge_alive")
                    elif data == "bridge_shutdown":
                        print(f"Received shutdown command from {addr}. Shutting down...")
                        client.send("bridge_closing".encode())
                        os._exit(0)
                    elif data == "bridge_status":
                        if bot_instance.is_ready:
                            client.send("bridge_ready".encode())
                        else:
                            client.send("bridge_not_ready".encode())
                    elif data == "bridge_status_check":
                        if bot_instance.is_ready and bot_instance.selected_channel:
                            client.send("bridge_ready_with_channel".encode())
                        else:
                            client.send("bridge_running_not_ready".encode())
                    elif data == "say_hello":
                        client.send("hello".encode())
                        print(f"Responded to say_hello from {addr} with 'hello'")
                    else:
                        if data.startswith("uid:"):
                            parts = data.split(":", 4)
                            if len(parts) >= 4:
                                uid = parts[1]
                                action = parts[2]
                                task_number = parts[3] if len(parts) > 3 else ""
                                # Use uid:task for 'start' tasks to match msg responses
                                if action == "task" and task_number == "start":
                                    task_key = f"{uid}:task"
                                else:
                                    task_key = f"{uid}:{task_number}" if action == "task" else f"{uid}:task"
                                bot_instance.pending_tasks[task_key] = addr
                        asyncio.run_coroutine_threadsafe(bot_instance.queue.put((data, addr)), bot_instance.loop)
                        client.send("received".encode())
            except Exception as e:
                print(f"Error in TCP server: {e}")
            finally:
                if addr in bot_instance.tcp_clients:
                    del bot_instance.tcp_clients[addr]
                client.close()
                
        except socket.timeout:
            if time.time() - bot_instance.last_activity > INACTIVITY_TIMEOUT:
                print(f"No TCP activity for {INACTIVITY_TIMEOUT} seconds. Shutting down...")
                os._exit(0)
        except Exception as e:
            print(f"Error in TCP server: {e}")
            break

async def main():
    CONFIG_VALUE = load_config()
    intents = Intents.default()
    intents.messages = True
    intents.message_content = True
    bot = BridgeBot(intents=intents)
    tcp_thread = threading.Thread(target=tcp_server, args=(bot,), daemon=True)
    tcp_thread.start()
    await bot.start(CONFIG_VALUE)

if __name__ == "__main__":
    asyncio.run(main())

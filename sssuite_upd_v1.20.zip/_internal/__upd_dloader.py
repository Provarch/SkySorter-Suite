import sys
import requests
import tkinter as tk
from tkinter import ttk
from pathlib import Path
import shutil
import threading
import os
import time
import subprocess

def download_with_progress(zip_url, local_path):
    root = tk.Tk()
    root.title("Downloading Update")
    root.overrideredirect(True)  # Remove title bar
    root.attributes("-topmost", True)
    root.configure(bg="#000000")

    # Center window on screen
    root.update_idletasks()
    width = 300
    height = 100
    screen_width = root.winfo_screenwidth()
    screen_height = root.winfo_screenheight()
    x = (screen_width - width) // 2
    y = (screen_height - height) // 2
    root.geometry(f"{width}x{height}+{x}+{y}")

    # Main frame
    main_frame = tk.Frame(root, bg="#000000")
    main_frame.pack(fill="both", expand=True, padx=10, pady=10)

    # Label
    label = tk.Label(main_frame, text="Downloading update...", bg="#000000", fg="white", font=("Consolas", 10))
    label.pack(pady=(0, 10))

    # Progress bar (black background, green bar)
    style = ttk.Style()
    style.configure("Custom.Horizontal.TProgressbar", background="limegreen", troughcolor="#000000")
    progress = ttk.Progressbar(main_frame, style="Custom.Horizontal.TProgressbar", length=200, mode="determinate")
    progress.pack(pady=(0, 10))

    def download():
        try:
            with requests.get(zip_url, stream=True, timeout=15) as r:
                r.raise_for_status()
                total_size = int(r.headers.get('content-length', 0))
                chunk_size = 8192
                downloaded = 0

                with open(local_path, 'wb') as f:
                    for chunk in r.iter_content(chunk_size=chunk_size):
                        if chunk:
                            f.write(chunk)
                            downloaded += len(chunk)
                            if total_size > 0:
                                progress_value = (downloaded / total_size) * 100
                                progress['value'] = progress_value
                                root.update_idletasks()  # Update UI
                print(f"Downloaded update to: {local_path}")
        except Exception as e:
            print(f"Download failed: {e}")
        finally:
            root.destroy()

    # Start download in a separate thread to keep UI responsive
    threading.Thread(target=download, daemon=True).start()

    # Drag functionality
    drag_data = {"x": 0, "y": 0, "dragging": False}

    def start_drag(event):
        drag_data["x"] = event.x
        drag_data["y"] = event.y
        drag_data["dragging"] = True

    def stop_drag(event):
        drag_data["dragging"] = False

    def drag(event):
        if drag_data["dragging"]:
            x = root.winfo_x() + (event.x - drag_data["x"])
            y = root.winfo_y() + (event.y - drag_data["y"])
            root.geometry(f"+{x}+{y}")

    root.bind("<Button-1>", start_drag)
    root.bind("<ButtonRelease-1>", stop_drag)
    root.bind("<B1-Motion>", drag)

    root.mainloop()

if __name__ == "__main__":
    if len(sys.argv) != 3:
        print("Usage: __upd_dloader.py <zip_url> <local_path>")
        sys.exit(1)
    zip_url = sys.argv[1]
    local_path = Path(sys.argv[2])
    download_with_progress(zip_url, local_path)
    
    # Locate __updater.py in the same directory as this script
    script_dir = os.path.dirname(os.path.abspath(__file__))
    updater_path = os.path.join(script_dir, '__updater.py')
    
    # Check if __updater.py exists
    if not os.path.exists(updater_path):
        print(f"Error: __updater.py not found at {updater_path}")
        sys.exit(1)
    
    print(f"Starting __updater.py")
    time.sleep(3)  # Brief delay to ensure download completes
    
    # Launch __updater.py as a detached process
    try:
        subprocess.Popen(
            [sys.executable, updater_path],
            creationflags=subprocess.DETACHED_PROCESS,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            close_fds=True
        )
        print(f"Launched __updater.py successfully")
    except Exception as e:
        print(f"Failed to launch __updater.py: {e}")
        sys.exit(1)
    
    # Exit the downloader script
    sys.exit(0)

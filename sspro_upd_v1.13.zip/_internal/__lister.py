from PIL import Image
import re
import os
import sys
from glob import glob
from collections import defaultdict

# Regex for extracting actual_id
sky_regex = r"(\d{2,8}\.\w{12,13})"

# Archive file extensions
archive_extensions = {'.zip', '.rar', '.7z'}

def read_xmp_and_exif_data(file_path):
    try:
        with Image.open(file_path) as img:
            img.load()
            xmp_data = img.getxmp()
            title = None
            if "xmpmeta" in xmp_data and "RDF" in xmp_data["xmpmeta"]:
                rdf = xmp_data["xmpmeta"]["RDF"]
                if "Description" in rdf:
                    desc = rdf["Description"]
                    if isinstance(desc, dict) and "title" in desc:
                        title_data = desc["title"]
                        if isinstance(title_data, dict) and "Alt" in title_data:
                            title = title_data["Alt"].get("li", {}).get("text")

            xp_subject = None
            exif_data = img.getexif()
            if 0x9c9f in exif_data:  # XPSubject tag
                subject_raw = exif_data[0x9c9f]
                if isinstance(subject_raw, tuple):
                    xp_subject = bytes(subject_raw).decode("utf-16", errors="ignore").rstrip("\x00")
                elif isinstance(subject_raw, bytes):
                    xp_subject = subject_raw.decode("utf-16", errors="ignore").rstrip("\x00")

            artist = None
            if 0x13b in exif_data:  # Artist tag
                artist_raw = exif_data[0x13b]
                if isinstance(artist_raw, bytes):
                    artist = artist_raw.decode("utf-8", errors="ignore")
                elif isinstance(artist_raw, str):
                    artist = artist_raw

            if title and xp_subject:
                actual_id_match = re.search(sky_regex, xp_subject)
                actual_id = actual_id_match.group(1) if actual_id_match else None
                title_parts = [part.strip() for part in title.split("|")]
                if len(title_parts) >= 3:
                    model_title = title_parts[0]
                    subcategory = title_parts[-2]
                    category = title_parts[-1]
                    # Ensure consistent padding to 21 characters
                    padded_actual_id = f"{actual_id: <21}"
                    is_pro = "ProSky" in artist if artist else False
                    return f"{padded_actual_id} - {model_title} | {subcategory} | {category}", is_pro
            return None, None
    except Exception as e:
        print(f"Error processing {file_path}: {str(e)}", flush=True)
        return None, None

def numeric_sort_key(line):
    actual_id = line.split(" - ")[0].strip()
    numeric_part, hex_part = actual_id.split(".", 1)
    return (int(numeric_part), hex_part)

def read_existing_report(output_file):
    """Read existing report file to get processed archive paths and existing models."""
    processed_archives = set()
    identifiable_models = set()  # Use set to avoid duplicates
    unrecognized_models = set()  # Use set to avoid duplicates
    if os.path.exists(output_file):
        with open(output_file, "r", encoding="utf-8") as f:
            current_section = None
            for line in f:
                line = line.strip()
                if line.startswith("Identifiable Sky Models:"):
                    current_section = "identifiable"
                    continue
                elif line.startswith("Unrecognized Sky Models (or missing image):"):
                    current_section = "unrecognized"
                    continue
                elif not line or line.startswith("Sky-lister results"):
                    continue
                if current_section == "identifiable" and line:
                    model_id = line.split(" - ")[0].strip()
                    model_type = line.split(" - ")[1].strip()
                    model_desc = line.split(" - ")[2].strip()
                    is_pro = model_type == "Pro"
                    identifiable_models.add((f"{model_id} - {model_desc}", is_pro))
                elif current_section == "unrecognized" and line:
                    archive_path = line.split(" (")[0]
                    unrecognized_models.add(line)
                    processed_archives.add(archive_path)
    return processed_archives, list(identifiable_models), list(unrecognized_models)

def write_report(output_file, all_identifiable_models, all_unrecognized_models, folder_name, is_final=False):
    """Write or update the report file with all models."""
    # Sort identifiable models
    all_identifiable_models.sort(key=lambda x: numeric_sort_key(x[0]))
    pro_count = sum(1 for _, is_pro in all_identifiable_models if is_pro)
    free_count = len(all_identifiable_models) - pro_count
    total_identifiable = len(all_identifiable_models)
    total_unrecognized = len(all_unrecognized_models)

    with open(output_file, "w", encoding="utf-8") as f:
        header = (
            f"Sky-lister results: {total_identifiable} Identifiable "
            f"({pro_count} Pro and {free_count} FREE), "
            f"{total_unrecognized} Unrecognized/Non-Sky models in {folder_name}"
        )
        if not is_final:
            header += " (Partial Report)"
        header += "\n\n"
        f.write(header)
        f.write("Identifiable Sky Models:\n")
        for model, is_pro in all_identifiable_models:
            model_type = "Pro" if is_pro else "FREE"
            f.write(f"{model.split(' - ')[0]} - {model_type} - {model.split(' - ')[1]}\n")
        f.write("\nUnrecognized Sky Models (or missing image):\n")
        for model in all_unrecognized_models:
            f.write(model + "\n")

def process_folder(folder_path, source_folder, processed_archives, all_identifiable_models, all_unrecognized_models, output_file, folder_name):
    """Process a single folder: find archives, match images, and read metadata."""
    print(f"Scanning folder: {folder_path}", flush=True)
    
    archive_files = []
    new_identifiable_models = set()  # Use set to avoid duplicates
    new_unrecognized_models = set()  # Use set to avoid duplicates
    
    # Find all archive files in this folder (not in subfolders)
    for file in os.listdir(folder_path):
        file_path = os.path.join(folder_path, file)
        if os.path.isfile(file_path) and file.lower().endswith(tuple(archive_extensions)):
            archive_files.append(file_path)
    
    # For each archive, find the matching image
    for archive_path in archive_files:
        archive_rel_path = os.path.relpath(archive_path, source_folder)
        if archive_rel_path in processed_archives:
            print(f"Skipping already processed archive: {archive_rel_path}", flush=True)
            continue
        
        base_name = os.path.splitext(archive_path)[0]  # Strip extension at last dot
        jpg_pattern = f"{base_name}*.jpg"
        jpeg_pattern = f"{base_name}*.jpeg"
        matching_images = glob(jpg_pattern) + glob(jpeg_pattern)
        
        if matching_images:
            # Sort alphanumerically and take the first one
            first_image = sorted(matching_images)[0]
            result, is_pro = read_xmp_and_exif_data(first_image)
            if result:
                new_identifiable_models.add((result, is_pro))
            else:
                new_unrecognized_models.add(archive_rel_path)
        else:
            new_unrecognized_models.add(archive_rel_path + " (no accompanying image)")
    
    # Add new models to the global lists, avoiding duplicates
    all_identifiable_models.extend([model for model in new_identifiable_models if model not in set(all_identifiable_models)])
    all_unrecognized_models.extend([model for model in new_unrecognized_models if model not in set(all_unrecognized_models)])
    
    # Write updated report
    write_report(output_file, all_identifiable_models, all_unrecognized_models, folder_name)
    
    print(f"Finished processing folder: {folder_path}", flush=True)
    return new_identifiable_models, new_unrecognized_models

def generate_report(source_folder):
    if not os.path.isdir(source_folder):
        print(f"Error: {source_folder} is not a valid directory.", flush=True)
        return

    folder_name = os.path.basename(source_folder)
    parent_folder = os.path.dirname(source_folder)
    output_file = os.path.join(parent_folder, f"{folder_name}.txt")

    # Read existing report to get processed archives and models
    processed_archives, all_identifiable_models, all_unrecognized_models = read_existing_report(output_file)

    # Process the root folder first
    process_folder(source_folder, source_folder, processed_archives, all_identifiable_models, all_unrecognized_models, output_file, folder_name)

    # Process each subfolder
    for root, dirs, _ in os.walk(source_folder):
        if root == source_folder:  # Skip root folder as we've already processed it
            continue
        process_folder(root, source_folder, processed_archives, all_identifiable_models, all_unrecognized_models, output_file, folder_name)

    # Write final report
    write_report(output_file, all_identifiable_models, all_unrecognized_models, folder_name, is_final=True)
    print(f"Report generation complete: {output_file}", flush=True)

if __name__ == "__main__":
    print("Starting report generation...", flush=True)
    if len(sys.argv) > 1:
        # Join all arguments after script name to handle spaces in folder path
        source_folder = " ".join(sys.argv[1:]).strip()
        generate_report(source_folder)
    else:
        source_folder = input("Enter the source folder path: ").strip()
        generate_report(source_folder)

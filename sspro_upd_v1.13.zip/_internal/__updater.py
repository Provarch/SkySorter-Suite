import tkinter as tk
from tkinter import messagebox
import requests
import re
import webbrowser
import sys
from pathlib import Path

# Hardcoded variables for skySorter
cur_ver = 1.12  # Current version of skySorter
link_base = "https://drive.google.com/open?id="
ver_id = "1fU4dbBdsXm_LRGFRW1H4YAp-HqR7071a"  # Google Drive ID for skySorter version file

# Popup size (width x height)
POPUP_SIZE = "250x100"  # Consistent with skySorter UI

# Button style for popups, matching skySorter's aesthetic
button_style = {
    "bg": "#1e1e1e",
    "fg": "white",
    "font": ("Consolas", 10),
    "bd": 0,  # Changed from 2 to 0 to remove default border
    "relief": "flat",  # Changed from solid to flat since we’re handling the border with a frame
    "activebackground": "#444444",
    "activeforeground": "white"
}

# Offset values for popup positioning
NEW_VERSION_OFFSET_X = -410  # X offset for new version popup
NEW_VERSION_OFFSET_Y = 100   # Y offset for new version popup
UP_TO_DATE_OFFSET_X = -410   # X offset for up-to-date popup
UP_TO_DATE_OFFSET_Y = 100    # Y offset for up-to-date popup


# Popup for "New Version Available" with Update/Cancel options
def show_new_version_popup(latest_ver, zip_id, dialog_x=None, dialog_y=None):
    new_version_dialog = tk.Toplevel()
    new_version_dialog.overrideredirect(True)
    new_version_dialog.attributes("-topmost", True)  # Always on top
    new_version_dialog.configure(bg="white")
    
    # Initialize drag variables
    drag_data = {"x": 0, "y": 0, "dragging": False}
    
    # Position popup with offset
    if dialog_x is not None and dialog_y is not None:
        new_version_dialog.geometry(f"{POPUP_SIZE}+{dialog_x + NEW_VERSION_OFFSET_X}+{dialog_y + NEW_VERSION_OFFSET_Y}")
    else:
        new_version_dialog.geometry(POPUP_SIZE)
    
    inner_frame = tk.Frame(new_version_dialog, bg="#1e1e1e")
    inner_frame.pack(fill="both", expand=True, padx=2, pady=2)
    
    tk.Label(inner_frame, 
             text=f"New skySorter version {latest_ver} available!", 
             bg="#1e1e1e", fg="white", font=("Consolas", 10), justify="center").pack(pady=5)
    
    # Buttons frame for Update and Cancel with white border
    button_frame = tk.Frame(inner_frame, bg="#1e1e1e", highlightbackground="white", highlightthickness=2)
    button_frame.pack(pady=5)
    
    def update_action():
        webbrowser.open(f"{link_base}{zip_id}")
        new_version_dialog.destroy()
    
    def cancel_action():
        new_version_dialog.destroy()
    
    tk.Button(button_frame, text="Update", command=update_action, **button_style).pack(side=tk.LEFT, padx=5)
    tk.Button(button_frame, text="Cancel", command=cancel_action, **button_style).pack(side=tk.LEFT, padx=5)
    
    # Enable dragging
    def start_drag(event):
        drag_data["x"] = event.x
        drag_data["y"] = event.y
        drag_data["dragging"] = True
    
    def stop_drag(event):
        drag_data["dragging"] = False
    
    def drag(event):
        if drag_data["dragging"]:
            x = new_version_dialog.winfo_x() + (event.x - drag_data["x"])
            y = new_version_dialog.winfo_y() + (event.y - drag_data["y"])
            new_version_dialog.geometry(f"+{x}+{y}")
    
    inner_frame.bind("<Button-1>", start_drag)
    inner_frame.bind("<ButtonRelease-1>", stop_drag)
    inner_frame.bind("<B1-Motion>", drag)
    
    def update_action():
        webbrowser.open(f"{link_base}{zip_id}")
        new_version_dialog.destroy()
    
    def cancel_action():
        new_version_dialog.destroy()
    
    tk.Button(button_frame, text="Update", command=update_action, **button_style).pack(side=tk.LEFT, padx=5)
    tk.Button(button_frame, text="Cancel", command=cancel_action, **button_style).pack(side=tk.LEFT, padx=5)
    
    # Enable dragging
    def start_drag(event):
        drag_data["x"] = event.x
        drag_data["y"] = event.y
        drag_data["dragging"] = True
    
    def stop_drag(event):
        drag_data["dragging"] = False
    
    def drag(event):
        if drag_data["dragging"]:
            x = new_version_dialog.winfo_x() + (event.x - drag_data["x"])
            y = new_version_dialog.winfo_y() + (event.y - drag_data["y"])
            new_version_dialog.geometry(f"+{x}+{y}")
    
    inner_frame.bind("<Button-1>", start_drag)
    inner_frame.bind("<ButtonRelease-1>", stop_drag)
    inner_frame.bind("<B1-Motion>", drag)

# Popup for errors
def show_error_popup(message, dialog_x=None, dialog_y=None):
    error_dialog = tk.Toplevel()
    error_dialog.overrideredirect(True)
    error_dialog.attributes("-topmost", True)  # Always on top
    
    if dialog_x is not None and dialog_y is not None:
        error_dialog.geometry(f"{POPUP_SIZE}+{dialog_x+133}+{dialog_y+133}")
    else:
        error_dialog.geometry(POPUP_SIZE)
    
    error_dialog.configure(bg="white")
    
    inner_frame = tk.Frame(error_dialog, bg="#1e1e1e")
    inner_frame.pack(fill="both", expand=True, padx=2, pady=2)
    
    tk.Label(inner_frame, 
             text=message, 
             bg="#1e1e1e", fg="white", font=("Consolas", 10), justify="center").pack(pady=10)
    
    # Frame for OK button with white border
    button_frame = tk.Frame(inner_frame, bg="#1e1e1e", highlightbackground="white", highlightthickness=2)
    button_frame.pack(pady=5)
    tk.Button(button_frame, text="OK", command=error_dialog.destroy, **button_style).pack()

# Popup for "Up to Date" with dragging
def show_up_to_date_popup(dialog_x=None, dialog_y=None):
    up_to_date_dialog = tk.Toplevel()
    up_to_date_dialog.overrideredirect(True)
    up_to_date_dialog.attributes("-topmost", True)  # Always on top
    up_to_date_dialog.configure(bg="white")
    
    # Initialize drag variables
    drag_data = {"x": 0, "y": 0, "dragging": False}
    
    # Position popup with offset
    if dialog_x is not None and dialog_y is not None:
        up_to_date_dialog.geometry(f"{POPUP_SIZE}+{dialog_x + UP_TO_DATE_OFFSET_X}+{dialog_y + UP_TO_DATE_OFFSET_Y}")
    else:
        up_to_date_dialog.geometry(POPUP_SIZE)
    
    inner_frame = tk.Frame(up_to_date_dialog, bg="#1e1e1e")
    inner_frame.pack(fill="both", expand=True, padx=2, pady=2)
    
    tk.Label(inner_frame, 
             text=f"skySorter is up to date \n (v{cur_ver}).", 
             bg="#1e1e1e", fg="white", font=("Consolas", 10), justify="center").pack(pady=10)
    
    # Frame for OK button with white border
    button_frame = tk.Frame(inner_frame, bg="#1e1e1e", highlightbackground="white", highlightthickness=2)
    button_frame.pack(pady=5)
    tk.Button(button_frame, text="OK", command=up_to_date_dialog.destroy, **button_style).pack()
    
    # Enable dragging
    def start_drag(event):
        drag_data["x"] = event.x
        drag_data["y"] = event.y
        drag_data["dragging"] = True
    
    def stop_drag(event):
        drag_data["dragging"] = False
    
    def drag(event):
        if drag_data["dragging"]:
            x = up_to_date_dialog.winfo_x() + (event.x - drag_data["x"])
            y = up_to_date_dialog.winfo_y() + (event.y - drag_data["y"])
            up_to_date_dialog.geometry(f"+{x}+{y}")
    
    inner_frame.bind("<Button-1>", start_drag)
    inner_frame.bind("<ButtonRelease-1>", stop_drag)
    inner_frame.bind("<B1-Motion>", drag)
    
    # Enable dragging
    def start_drag(event):
        drag_data["x"] = event.x
        drag_data["y"] = event.y
        drag_data["dragging"] = True
    
    def stop_drag(event):
        drag_data["dragging"] = False
    
    def drag(event):
        if drag_data["dragging"]:
            x = up_to_date_dialog.winfo_x() + (event.x - drag_data["x"])
            y = up_to_date_dialog.winfo_y() + (event.y - drag_data["y"])
            up_to_date_dialog.geometry(f"+{x}+{y}")
    
    inner_frame.bind("<Button-1>", start_drag)
    inner_frame.bind("<ButtonRelease-1>", stop_drag)
    inner_frame.bind("<B1-Motion>", drag)

# Version checking function
def check_version(dialog_x=None, dialog_y=None):
    try:
        # Construct the metadata URL
        metadata_url = f"https://drive.google.com/uc?id={ver_id}&export=download"
        
        # Make a HEAD request to get file information
        headers = {'User-Agent': 'Mozilla/5.0'}
        response = requests.head(metadata_url, allow_redirects=True, headers=headers)
        
        # Extract filename from Content-Disposition header
        content_disp = response.headers.get('Content-Disposition', '')
        filename_match = re.search(r'filename="([^"]+)"', content_disp)
        
        if not filename_match:
            show_error_popup("Could not extract filename", dialog_x, dialog_y)
            return
        
        filename = filename_match.group(1)
        
        # Extract version and zip ID from filename (adjusted for skytoolkit)
        pattern = r'skytoolkit - v([\d.]+) - ([^.]+)(\.txt)?'
        match = re.search(pattern, filename)
        
        if not match:
            show_error_popup("Could not parse version or zip ID", dialog_x, dialog_y)
            return
        
        latest_ver = float(match.group(1))  
        zip_id = match.group(2)            
        
        if latest_ver > cur_ver:
            show_new_version_popup(latest_ver, zip_id, dialog_x, dialog_y)
        else:
            show_up_to_date_popup(dialog_x, dialog_y)
            
    except Exception as e:
        show_error_popup(f"Error checking version: {str(e)}", dialog_x, dialog_y)

if __name__ == '__main__':
    root = tk.Tk()
    root.withdraw()  # Hide the main window
    # Get dialog position from command-line arguments if provided
    dialog_x = int(sys.argv[1]) if len(sys.argv) > 1 else None
    dialog_y = int(sys.argv[2]) if len(sys.argv) > 2 else None
    check_version(dialog_x, dialog_y)
    root.mainloop()

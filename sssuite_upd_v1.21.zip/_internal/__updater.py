import psutil
import os
import subprocess
import pathlib
import json
import re
import time
import zipfile

def get_current_version():
    """Read the current version from curr.ver file."""
    try:
        curr_ver_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'curr.ver')
        with open(curr_ver_path, 'r') as f:
            data = json.load(f)
            return data.get('curr_ver', '0.0')
    except (FileNotFoundError, json.JSONDecodeError, KeyError) as e:
        print(f"Error reading curr.ver: {e}")
        return '0.0'

def check_update_zip(curr_ver):
    """Check for update zip file and return its path if version is higher."""
    cwd = os.path.dirname(os.path.abspath(__file__))
    update_zip_path = None
    zip_ver = None
    
    # Look for zip files with '_upd_v' in the name
    for file in os.listdir(cwd):
        if file.lower().endswith('.zip') and '_upd_v' in file.lower():
            # Extract version number from filename (e.g., sspro_upd_v1.13.zip -> 1.13)
            match = re.search(r'_upd_v([\d.]+)\.zip', file.lower())
            if match:
                zip_ver = match.group(1)
                # Compare versions
                if version_compare(zip_ver, curr_ver) > 0:
                    update_zip_path = os.path.join(cwd, file)
                    print(f"Found update package {file} (v{zip_ver}) newer than current version (v{curr_ver})")
                    return update_zip_path, zip_ver
    print("No more recent updater found.")
    return None, None

def unzip_update(zip_path, parent_dir):
    """Unzip the update zip file to the parent directory, overwriting if necessary."""
    if zip_path:
        if not os.path.exists(zip_path):
            print(f"Error: Zip file {zip_path} does not exist.")
            return
        print(f"Extracting to: {parent_dir}")
        try:
            with zipfile.ZipFile(zip_path, 'r') as zip_ref:
                # Extract all files to parent_dir, overwriting existing files
                for member in zip_ref.namelist():
                    # Get the destination path
                    dest_path = os.path.join(parent_dir, member)
                    # Ensure directory structure exists
                    os.makedirs(os.path.dirname(dest_path), exist_ok=True)
                    # Extract file, overwriting if it exists
                    with zip_ref.open(member) as source, open(dest_path, 'wb') as target:
                        target.write(source.read())
            print(f"Successfully extracted {os.path.basename(zip_path)} to {parent_dir}")
        except (zipfile.BadZipFile, OSError) as e:
            print(f"Failed to extract {os.path.basename(zip_path)}: {e}")

def version_compare(v1, v2):
    """Compare two version strings (e.g., '1.13' > '1.11')."""
    v1_parts = list(map(int, v1.split('.')))
    v2_parts = list(map(int, v2.split('.')))
    
    # Pad with zeros if lengths differ
    max_len = max(len(v1_parts), len(v2_parts))
    v1_parts.extend([0] * (max_len - len(v1_parts)))
    v2_parts.extend([0] * (max_len - len(v2_parts)))
    
    for i in range(max_len):
        if v1_parts[i] > v2_parts[i]:
            return 1
        elif v1_parts[i] < v2_parts[i]:
            return -1
    return 0

def get_script_parent_directory():
    """Get the parent directory of the current script."""
    script_dir = os.path.dirname(os.path.abspath(__file__))
    parent_dir = str(pathlib.Path(script_dir).parent)
    return parent_dir

def get_python_processes(script_parent_dir):
    """
    Get Python processes running from the parent directory, excluding __updater.py and idlelib.run.
    Handles cases where proc.info['cwd'] (or other fields) can be None.
    """
    python_processes = []
    parent_lower = (script_parent_dir or "").lower()

    for proc in psutil.process_iter(['pid', 'name', 'exe', 'cmdline', 'cwd']):
        try:
            name = (proc.info.get('name') or "").lower()
            if name not in ('python.exe', 'pythonw.exe'):
                continue

            cmdline = proc.info.get('cmdline') or []
            cmdline_str = " ".join(cmdline).lower()

            # Skip __updater.py and idlelib.run processes
            if '__updater.py' in cmdline_str or 'idlelib.run' in cmdline_str:
                continue

            cwd = proc.info.get('cwd')
            if not cwd:
                # Can't determine working directory; skip it safely
                continue

            process_cwd = str(cwd).lower()
            if not process_cwd.startswith(parent_lower):
                continue

            process_info = {
                'pid': proc.info.get('pid'),
                'name': proc.info.get('name'),
                'directory': None,
                'cmdline': cmdline,
                'cmdline_str': " ".join(cmdline),
                'cwd': cwd
            }

            try:
                process_info['directory'] = os.path.dirname(proc.exe())
            except (psutil.AccessDenied, psutil.NoSuchProcess, TypeError):
                process_info['directory'] = 'Access Denied'

            python_processes.append(process_info)

        except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
            continue
        except Exception:
            # Last-resort safety; don't let one weird proc kill the updater
            continue

    return python_processes


def close_processes(processes):
    """Automatically close processes and return closed ones."""
    if not processes:
        return []
    
    closed_processes = []
    for proc in processes:
        try:
            psutil.Process(proc['pid']).terminate()
            print(f"Terminated process {proc['name']} (PID: {proc['pid']})")
            closed_processes.append(proc)
        except (psutil.NoSuchProcess, psutil.AccessDenied) as e:
            print(f"Failed to terminate process {proc['name']} (PID: {proc['pid']}): {e}")
    # Wait briefly to ensure processes are fully terminated
    time.sleep(1)
    
    return closed_processes

def relaunch_processes(closed_processes):
    """Automatically relaunch closed processes."""
    if not closed_processes:
        return
    
    for proc in closed_processes:
        try:
            subprocess.Popen(proc['cmdline'], creationflags=subprocess.DETACHED_PROCESS)
            print(f"Relaunched process with command: {' '.join(proc['cmdline'])}")
        except Exception as e:
            print(f"Failed to relaunch process with command {' '.join(proc['cmdline'])}: {e}")

def main():
    # Get current version
    curr_ver = get_current_version()
    print(f"Current version: {curr_ver}")
    
    # Get parent directory
    script_parent_dir = get_script_parent_directory()
    print(f"\nDetecting running Python processes in parent directory: {script_parent_dir} (excluding '__updater.py' and 'idlelib.run')...\n")
    
    # Get list of Python processes
    processes = get_python_processes(script_parent_dir)
    
    if not processes:
        print("No matching Python processes found.")
    
    # Print details for each process
    for proc in processes:
        print(f"Process: {proc['name']}")
        print(f"PID: {proc['pid']}")
        print(f"Executable Directory: {proc['directory']}")
        print(f"Working Directory: {proc['cwd']}")
        print(f"Command Line: {proc['cmdline_str']}")
        print("-" * 50)
    
    # Check for update zip
    update_zip_path, zip_ver = check_update_zip(curr_ver)
    
    # If no newer update, exit silently
    if not update_zip_path:
        return
    
    # If newer update found, proceed with closing processes
    closed_processes = close_processes(processes)
    
    # Unzip update to parent directory
    unzip_update(update_zip_path, script_parent_dir)
    
    # Relaunch processes
    relaunch_processes(closed_processes)

if __name__ == "__main__":
    main()

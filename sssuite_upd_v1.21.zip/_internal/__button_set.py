from PyQt6.QtWidgets import QWidget, QHBoxLayout, QVBoxLayout, QToolButton, QToolTip, QLineEdit, QLabel
from PyQt6.QtCore import Qt, QTimer, QPoint, QThread, pyqtSignal  # Added QThread and pyqtSignal
import webbrowser
from pathlib import Path
import platform
import uuid
import hashlib
import subprocess
import sys
import json
import os

def _cfg_has_patreon_uid(cfg_path: Path) -> bool:
    try:
        if not cfg_path.exists():
            return False
        with open(cfg_path, "r", encoding="utf-8") as f:
            data = json.load(f)
        uid = (data.get("patreon_user_id") or "").strip()
        return bool(uid)
    except Exception:
        return False

class ToolsDropdown(QWidget):
    def __init__(self, parent=None, gfx_dir=None, main_window=None, button_set=None, x_offset=0, y_offset=0, button_width=90):
        super().__init__(parent)
        self.setWindowFlags(Qt.WindowType.FramelessWindowHint | Qt.WindowType.WindowStaysOnTopHint)
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        self.gfx_dir = gfx_dir
        self.main_window = main_window
        self.button_set = button_set  # Reference to ButtonSet
        self.x_offset = x_offset  # Horizontal offset in pixels
        self.y_offset = y_offset  # Vertical offset in pixels
        self.button_width = button_width  # Width for all buttons in pixels

        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(5)

        # Skydrop button
        skydrop_button = QToolButton()
        skydrop_button.setText("DROP")
        skydrop_button.setFixedWidth(self.button_width)
        skydrop_button.setStyleSheet("""
            QToolButton { 
                background-color: rgba(30, 30, 30, 200); 
                color: white; 
                padding: 5px; 
                border-radius: 4px; 
                border: none; 
                text-align: center; 
            }
            QToolButton:hover { 
                background-color: rgba(77, 77, 77, 200); 
            }
        """)
        skydrop_button.setToolTip("<b>Skydrop</b><br>A handy droplet script that mimics smart merge script")
        skydrop_button.clicked.connect(lambda: [self.launch_skydrop(), self.button_set.toggle_dropdown()])
        layout.addWidget(skydrop_button)

        # Skynizer button
        skynizer_button = QToolButton()
        skynizer_button.setText("NIZER")
        skynizer_button.setFixedWidth(self.button_width)
        skynizer_button.setStyleSheet("""
            QToolButton { 
                background-color: rgba(30, 30, 30, 200); 
                color: white; 
                padding: 5px; 
                border-radius: 4px; 
                border: none; 
                text-align: center; 
            }
            QToolButton:hover { 
                background-color: rgba(77, 77, 77, 200); 
            }
        """)
        skynizer_button.setToolTip("<b>Skynizer</b><br>Click to launch SkyNizer")
        skynizer_button.clicked.connect(lambda: [self.launch_skynizer(), self.button_set.toggle_dropdown()])
        layout.addWidget(skynizer_button)

        # Skylister button
        skylister_button = QToolButton()
        skylister_button.setText("LISTER")
        skylister_button.setFixedWidth(self.button_width)
        skylister_button.setStyleSheet("""
            QToolButton { 
                background-color: rgba(30, 30, 30, 200); 
                color: white; 
                padding: 5px; 
                border-radius: 4px; 
                border: none; 
                text-align: center; 
            }
            QToolButton:hover { 
                background-color: rgba(77, 77, 77, 200); 
            }
        """)
        skylister_button.setToolTip("<b>Skylister</b><br>Generate a report of 3dsky models")
        skylister_button.clicked.connect(lambda: [self.main_window.run_skylister(), self.button_set.toggle_dropdown()])
        layout.addWidget(skylister_button)



        # Resorter button
        resorter_button = QToolButton()
        resorter_button.setText("RE-SORTER")
        resorter_button.setFixedWidth(self.button_width)
        resorter_button.setStyleSheet("""
            QToolButton { 
                background-color: rgba(30, 30, 30, 200); 
                color: white; 
                padding: 5px; 
                border-radius: 4px; 
                border: none; 
                text-align: center; 
            }
            QToolButton:hover { 
                background-color: rgba(77, 77, 77, 200); 
            }
        """)
        resorter_button.setToolTip("<b>Resorter</b><br>Re-sort models in the 3D Sky bank")
        resorter_button.clicked.connect(lambda: [self.launch_resorter(), self.button_set.toggle_dropdown()])
        layout.addWidget(resorter_button)


        # Updates button
        updates_button = QToolButton()
        updates_button.setText("UPDATE")
        updates_button.setFixedWidth(self.button_width)
        updates_button.setStyleSheet("""
            QToolButton { 
                background-color: rgba(30, 30, 30, 200); 
                color: white; 
                padding: 5px; 
                border-radius: 4px; 
                border: none; 
                text-align: center; 
            }
            QToolButton:hover { 
                background-color: rgba(77, 77, 77, 200); 
            }
        """)
        updates_button.setToolTip("<b>Updates</b><br>Check for skySorter updates")
        updates_button.clicked.connect(lambda: [self.launch_checker(updates_button), self.button_set.toggle_dropdown()])
        
        # UID button
        self.uid_button = QToolButton()
        self.uid_button.setText("Copy UID")
        self.uid_button.setFixedWidth(self.button_width)
        self.uid_button.setStyleSheet("""
            QToolButton { 
                background-color: rgba(30, 30, 30, 200); 
                color: #00ff00; 
                padding: 5px; 
                border-radius: 4px; 
                font-family: Consolas; 
                font-size: 12px; 
                border: none; 
                text-align: center; 
            }
            QToolButton:hover { 
                background-color: rgba(77, 77, 77, 200); 
            }
        """)
        self.uid_button.setToolTip("Click to copy the User ID to clipboard")
        self.uid_button.setCursor(Qt.CursorShape.PointingHandCursor)
        self.uid_button.clicked.connect(self.button_set.copy_uid_to_clipboard)
        layout.addWidget(self.uid_button)

        layout.addWidget(updates_button)


        

        
    class ResorterThread(QThread):
        output_signal = pyqtSignal(str)  # Signal to emit output lines

        def __init__(self, executable, script_path, sky_folder):
            super().__init__()
            self.executable = executable
            self.script_path = script_path
            self.sky_folder = sky_folder

        def run(self):
            try:
                args = [self.executable, str(self.script_path), self.sky_folder]
                process = subprocess.Popen(
                    args,
                    creationflags=subprocess.CREATE_NO_WINDOW,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.STDOUT,  # Combine stderr with stdout
                    text=True,
                    bufsize=1,  # Line buffering
                    universal_newlines=True
                )

                # Stream output line by line
                for line in iter(process.stdout.readline, ''):
                    if line:
                        self.output_signal.emit(line.strip())
                
                process.stdout.close()
                return_code = process.wait()
                if return_code != 0:
                    self.output_signal.emit(f"Resorter exited with return code {return_code}")
            except Exception as e:
                self.output_signal.emit(f"Error launching Resorter: {str(e)}")

    def launch_skynizer(self):
        skynizer_script = self.gfx_dir.parent / "__skyNizer.pyw"
        if not skynizer_script.exists():
            print(f"SkyNizer script not found at {skynizer_script}", flush=True)
            if self.main_window and hasattr(self.main_window, 'console_output'):
                self.main_window.console_output.append(f"Error: SkyNizer script not found at {skynizer_script}")
            return
        try:
            # Get the raw folder path from process_input
            raw_folder = self.main_window.process_input.text() if self.main_window else ""
            args = [sys.executable, str(skynizer_script)]
            # Add raw folder as sys arg if it exists and is a valid directory
            if raw_folder and Path(raw_folder).is_dir():
                args.append(raw_folder)
            subprocess.Popen(args, creationflags=subprocess.CREATE_NO_WINDOW)
        except Exception as e:
            error_msg = f"Error launching SkyNizer: {str(e)}"
            print(error_msg, flush=True)
            if self.main_window and hasattr(self.main_window, 'console_output'):
                self.main_window.console_output.append(error_msg)

    def launch_skydrop(self):
        skydrop_script = self.gfx_dir.parent / "__SkyDrop.pyw"
        if not skydrop_script.exists():
            print(f"SkyDrop script not found at {skydrop_script}", flush=True)
            return
        try:
            subprocess.Popen([sys.executable, str(skydrop_script)], creationflags=subprocess.CREATE_NO_WINDOW)
        except Exception as e:
            print(f"Error launching SkyDrop: {str(e)}", flush=True)
            
    def launch_checker(self, button):
        checker_script = self.gfx_dir.parent / "__upd_chcker.py"
        if not checker_script.exists():
            self.main_window.console_output.append(f"Error: Checker script not found at {checker_script}")
            return
        try:
            self.main_window.console_output.clear()
            self.main_window.console_output.append("Checking for updates...")
            self.main_window.process.setWorkingDirectory(str(self.gfx_dir.parent))
            self.main_window.process.start(
                sys.executable,
                [str(checker_script), "--ui-pid", str(os.getpid())]
            )
        except Exception as e:
            self.main_window.console_output.append(f"Error launching Checker: {str(e)}")
                
    def launch_resorter(self):
        # Path to resorter script
        resorter_script = self.gfx_dir.parent / "__resorter.py"
        if not resorter_script.exists():
            error_msg = f"Resorter script not found at {resorter_script}"
            print(error_msg, flush=True)
            if self.main_window and hasattr(self.main_window, 'console_output'):
                self.main_window.console_output.append(error_msg)
            return
        
        # Read sssuite.cfg for 3dsky_folder and sorting_type
        script_dir = Path(__file__).parent
        config_path = script_dir / "sssuite.cfg"
        default_config_path = script_dir / "default_config.json"

        # Load default config
        default_config = {}
        try:
            if default_config_path.exists():
                with open(default_config_path, 'r', encoding='utf-8') as f:
                    default_config = json.load(f)
            else:
                print(f"Default config not found at {default_config_path}, using empty defaults", flush=True)
        except Exception as e:
            error_msg = f"Error loading default config {default_config_path}: {str(e)}"
            print(error_msg, flush=True)
            if self.main_window and hasattr(self.main_window, 'console_output'):
                self.main_window.console_output.append(error_msg)
            return

        # Load user config
        config = default_config.copy()
        try:
            if config_path.exists():
                with open(config_path, 'r', encoding='utf-8') as f:
                    config.update(json.load(f))
            else:
                print(f"Config file not found at {config_path}, using defaults", flush=True)
        except Exception as e:
            error_msg = f"Error loading config {config_path}: {str(e)}"
            print(error_msg, flush=True)
            if self.main_window and hasattr(self.main_window, 'console_output'):
                self.main_window.console_output.append(error_msg)
            return

        # Get 3dsky_folder and sorting_type
        sky_folder = config.get('3dsky_folder', '')
        sorting_type = config.get('sorting_type', 'CAT')
        if not sky_folder:
            error_msg = "3dsky_folder not specified in sssuite.cfg"
            print(error_msg, flush=True)
            if self.main_window and hasattr(self.main_window, 'console_output'):
                self.main_window.console_output.append(error_msg)
            return
        if not Path(sky_folder).is_dir():
            error_msg = f"3dsky_folder is not a valid directory: {sky_folder}"
            print(error_msg, flush=True)
            if self.main_window and hasattr(self.main_window, 'console_output'):
                self.main_window.console_output.append(error_msg)
            return

        # Check if the Sky bank folder is large or on a mechanical drive
        file_count = sum(len(files) for _, _, files in os.walk(sky_folder))
        is_mechanical = False
        if platform.system() == 'Windows':
            import win32file
            drive = os.path.splitdrive(sky_folder)[0] + '\\'
            drive_type = win32file.GetDriveType(drive)
            is_mechanical = drive_type == win32file.DRIVE_FIXED  # Excludes SSDs or network drives

        LARGE_THRESHOLD = 100  # Adjust this threshold as needed
        if file_count > LARGE_THRESHOLD or is_mechanical:
            from PyQt6.QtWidgets import QMessageBox
            msg_box = QMessageBox(self.main_window)
            msg_box.setWindowTitle("Warning")
            msg_box.setText("Re-sorting a large Sky bank folder or using a mechanical hard drive may take a significant amount of time.")
            msg_box.setInformativeText("Do you want to continue?")
            msg_box.setStandardButtons(QMessageBox.StandardButton.Cancel | QMessageBox.StandardButton.Ok)
            msg_box.setDefaultButton(QMessageBox.StandardButton.Cancel)
            result = msg_box.exec()
            if result == QMessageBox.StandardButton.Cancel:
                print("Re-sorter cancelled by user", flush=True)
                if self.main_window and hasattr(self.main_window, 'console_output'):
                    self.main_window.console_output.append("Re-sorter cancelled by user")
                return

        # Log the attempt to the UI console
        attempt_msg = f"Launching resorter with folder: {sky_folder} and sorting_type: {sorting_type}"
        print(attempt_msg, flush=True)
        if self.main_window and hasattr(self.main_window, 'console_output'):
            self.main_window.console_output.append(attempt_msg)

        # Launch resorter in a separate thread
        self.resorter_thread = self.ResorterThread(sys.executable, resorter_script, sky_folder)
        self.resorter_thread.output_signal.connect(self.append_to_console)
        self.resorter_thread.finished.connect(lambda: print("Resorter thread finished", flush=True))
        self.resorter_thread.start()

    def append_to_console(self, text):
        """Append text to the UI console."""
        if self.main_window and hasattr(self.main_window, 'console_output'):
            self.main_window.console_output.append(text)
        print(text, flush=True)  # Also print to terminal for debugging

    def append_to_console(self, text):
        """Append text to the UI console."""
        if self.main_window and hasattr(self.main_window, 'console_output'):
            self.main_window.console_output.append(text)
        print(text, flush=True)  # Also print to terminal for debugging
                
                
    def show_at_position(self, position):
        self.move(position)
        self.show()

    def hide_dropdown(self):
        self.hide()

class ButtonSet(QWidget):
    def __init__(self, parent=None, user_uid=None, gfx_dir=None, main_window=None):
        super().__init__(parent)
        self.user_uid = user_uid  # Can be None initially
        self.gfx_dir = gfx_dir
        self.main_window = main_window
        # uid_button moved to ToolsDropdown
        self.tools_dropdown = None
        self.tools_button = None
        self.alias_input = None
        self.login_button = None
        self.dropdown_visible = False
        self._login_refresh_timer = QTimer(self)
        self._login_refresh_timer.setInterval(1500)
        self._login_refresh_timer.timeout.connect(self.refresh_login_button)
        self._login_refresh_timer.start()
        self.dropdown_timer = QTimer()  # Timer for auto-closing the dropdown
        self.dropdown_timer.setSingleShot(True)  # Timer fires only once
        self.dropdown_timer.timeout.connect(self.hide_dropdown_timeout)  # Connect to a method to hide the dropdown
        self.setup_ui()
        self.initialize_position()

    def setup_ui(self):
        main_layout = QHBoxLayout(self)
        main_layout.setContentsMargins(0, 0, 0, 0)
        main_layout.setSpacing(5)

        button_container = QWidget()
        button_layout = QHBoxLayout(button_container)
        button_layout.setContentsMargins(0, 0, 10, 0)
        button_layout.setSpacing(5)

        # Alias input field
        self.alias_input = QLineEdit()
        self.alias_input.setFixedWidth(120)
        self.alias_input.setText("Your alias...")
        self.alias_input.setStyleSheet("""
            QLineEdit { 
                background-color: rgba(61, 61, 61, 200); 
                color: white; 
                border: 1px solid #555555; 
                border-radius: 4px; 
                padding: 3px; 
            }
            QLineEdit:hover { 
                background-color: rgba(77, 77, 77, 200); 
            }
        """)
        self.alias_input.setToolTip("<b>Alias</b><br>Enter your Patreon username")
        self.alias_input.enterEvent = self.clear_on_hover
        self.alias_input.leaveEvent = self.restore_on_hover_off
        self.alias_input.textChanged.connect(self.main_window.save_config)
        button_layout.addWidget(self.alias_input)

        
        # Add "as" symbol
        at_symbol = QLabel("as")
        at_symbol.setStyleSheet("color: white; font-size: 14px;")
        button_layout.addWidget(at_symbol)

        
        # --- Login button 
        self.login_button = QToolButton()
        self.login_button.setFixedWidth(125)  # same width the team field used
        self.login_button.setText("Login with Patreon")
        self.login_button.setCursor(Qt.CursorShape.PointingHandCursor)
        self.login_button.setStyleSheet("""
            QToolButton { 
                background-color: rgba(30, 30, 30, 200); 
                color: white; 
                padding: 5px; 
                border-radius: 4px; 
                border: none; 
                text-align: center; 
            }
            QToolButton:hover { 
                background-color: rgba(77, 77, 77, 200); 
            }
        """)
        self.login_button.setToolTip(
            "<b>Login</b><br>"
            "Click to link Patreon if not linked yet.<br>"
            "Right-click to rebuild (re-authorize) and rewrite sssuite.cfg."
        )

        # Left click: gated in handler (only works if not linked)
        self.login_button.clicked.connect(self._on_login_left_click)

        # Right click: always available (even if linked)
        self.login_button.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.login_button.customContextMenuRequested.connect(
            lambda _: self._launch_patreon_login(rebuild=True)
        )

        button_layout.addWidget(self.login_button)

        # Set initial label/tooltip based on cfg
        self.refresh_login_button()


        # UID button moved to ToolsDropdown

        # Tools button
        self.tools_button = QToolButton()
        self.tools_button.setText("SKY-Tools")
        self.tools_button.setFixedWidth(90)
        self.tools_button.setStyleSheet("""
            QToolButton { 
                background-color: rgba(30, 30, 30, 200); 
                color: white; 
                padding: 5px; 
                border-radius: 4px; 
                border: none; 
                text-align: center; 
            }
            QToolButton:hover { 
                background-color: rgba(77, 77, 77, 200); 
            }
        """)
        self.tools_button.setToolTip("<b>Tools</b><br>Click to show available tools")
        self.tools_button.clicked.connect(self.toggle_dropdown)
        button_layout.addWidget(self.tools_button)


        # Create the dropdown widget with initial offset values and button width
        self.tools_dropdown = ToolsDropdown(None, self.gfx_dir, self.main_window, button_set=self, x_offset=10, y_offset=5, button_width=80)
        self.tools_dropdown.setWindowFlags(self.tools_dropdown.windowFlags() | Qt.WindowType.WindowStaysOnTopHint)
        
        main_layout.addStretch(1)
        main_layout.addWidget(button_container)

    def update_uid(self, new_uid):
        self.user_uid = new_uid
        # No need to update uid_button text as it now displays "Copy UID"

    def initialize_position(self):
        QTimer.singleShot(100, self.update_dropdown_position)

    def toggle_dropdown(self):
        if not self.dropdown_visible:
            self.update_dropdown_position()
            self.tools_dropdown.show()
            self.dropdown_visible = True
            self.dropdown_timer.start(6000)  # Start the timer for 6 seconds (6000 milliseconds)
        else:
            self.tools_dropdown.hide_dropdown()
            self.dropdown_visible = False
            self.dropdown_timer.stop()  # Stop the timer if manually closed

    def update_dropdown_position(self):
        if self.tools_button:
            button_pos = self.tools_button.mapToGlobal(QPoint(50, -34))
            dropdown_pos = QPoint(
                button_pos.x() + self.tools_dropdown.x_offset,
                button_pos.y() + self.tools_button.height() + self.tools_dropdown.y_offset
            )
            self.tools_dropdown.move(dropdown_pos)
            if self.dropdown_visible:
                self.tools_dropdown.show()

    def copy_uid_to_clipboard(self):
        from PyQt6.QtWidgets import QApplication

        cfg_path = Path(__file__).parent / "sssuite.cfg"
        pat_uid = ""

        try:
            if cfg_path.exists():
                with open(cfg_path, "r", encoding="utf-8") as f:
                    cfg = json.load(f)
                pat_uid = (cfg.get("patreon_user_id") or "").strip()
        except Exception:
            pat_uid = ""

        if pat_uid:
            hashed_uid = hashlib.sha256(pat_uid.encode("utf-8")).hexdigest()[:16]
            text_to_copy = hashed_uid
            tip = "Hashed UID copied to clipboard"
        else:
            text_to_copy = ""
            tip = "No patreon_user_id found in sssuite.cfg"

        QApplication.clipboard().setText(text_to_copy)

        # Tooltip feedback (keep your existing placement logic if you already have it)
        try:
            if self.tools_dropdown and hasattr(self.tools_dropdown, "uid_button"):
                btn = self.tools_dropdown.uid_button
                button_pos = btn.mapToGlobal(QPoint(0, 0))
                tooltip_pos = QPoint(button_pos.x(), button_pos.y() + btn.height())
                QToolTip.showText(tooltip_pos, tip, btn)
            else:
                QToolTip.showText(QPoint(0, 0), tip)
            QTimer.singleShot(2000, lambda: QToolTip.hideText())
        except Exception:
            pass



    def clear_on_hover(self, event):
        if self.alias_input.text() == "Your alias...":
            self.alias_input.clear()

    def restore_on_hover_off(self, event):
        if not self.alias_input.text().strip():
            self.alias_input.setText("Your alias...")



    def get_alias(self):
        text = self.alias_input.text() if self.alias_input else ""
        return "" if text in ["Your alias...", ""] else text    

    
    def set_alias(self, alias):
        if self.alias_input:
            self.alias_input.setText(alias if alias else "Your alias...")



    def _pat_login_script_path(self) -> Path:
        # Prefer internal dir if you have it; otherwise same folder as cfg
        # Adjust if your project layout differs
        return Path(__file__).parent / "_pat_login.py"

    def _cfg_path(self) -> Path:
        # Use the same directory your app uses for sssuite.cfg
        return Path(__file__).parent / "sssuite.cfg"

    
    def _read_pat_state(self) -> tuple[bool, str]:
        """
        Returns (linked, pat_name). Linked means patreon_user_id exists and non-empty.
        """
        cfg_path = self._cfg_path()
        if not cfg_path.exists():
            return (False, "")

        try:
            with open(cfg_path, "r", encoding="utf-8") as f:
                cfg = json.load(f)
            pat_uid = (cfg.get("patreon_user_id") or "").strip()
            pat_name = (cfg.get("pat_name") or "").strip()
            return (bool(pat_uid), pat_name)
        except Exception:
            return (False, "")

        
    def refresh_login_button(self):
        if not self.login_button:
            return

        linked, pat_name = self._read_pat_state()

        # IMPORTANT: keep enabled so right-click works
        self.login_button.setEnabled(True)

        # UI label: first name only + " @ Patreon"
        ui_name = ""
        if pat_name:
            first_name = pat_name.strip().split(" ", 1)[0]
            ui_name = f"\"{first_name}\" in PATREON"

        if linked:
            self.login_button.setText(ui_name if ui_name else "Linked")
            self.login_button.setToolTip(
                "<b>Linked</b><br>"
                + (f"Logged in as: {pat_name}<br>" if pat_name else "")
                + "Right-click to rebuild (re-authorize)."
            )
        else:
            self.login_button.setText("… in Patreon")
            self.login_button.setToolTip(
                "<b>Login</b><br>"
                "Click to link Patreon.<br>"
                "Right-click to rebuild."
            )



    def _launch_patreon_login(self, rebuild: bool = False):
        script = self._pat_login_script_path()
        if not script.exists():
            if self.main_window and hasattr(self.main_window, "console_output"):
                self.main_window.console_output.append(f"Error: Patreon login script not found: {script}")
            return

        args = [sys.executable, str(script)]
        if rebuild:
            args.append("-r")

        try:
            subprocess.Popen(args, cwd=str(script.parent))

            # Mark UI as "waiting for auth"; it will check once when the UI becomes active again.
            if self.main_window is not None:
                setattr(self.main_window, "_pat_login_pending", True)

            if self.main_window and hasattr(self.main_window, "console_output"):
                self.main_window.console_output.append(
                    "Launching Patreon login..." + (" (rebuild)" if rebuild else "")
                )
                self.main_window.console_output.append("Authorize in browser, then return to this window to finalize.")
        except Exception as e:
            if self.main_window and hasattr(self.main_window, "console_output"):
                self.main_window.console_output.append(f"Error launching Patreon login: {e}")


    def _on_login_left_click(self):
        linked, pat_name = self._read_pat_state()

        if linked:
            # Left-click should not launch if already linked; just report
            if self.main_window and hasattr(self.main_window, "console_output"):
                msg = f"Logged in to Patreon as {pat_name}" if pat_name else "Already linked to Patreon."
                self.main_window.console_output.append(msg)
            return

        self._launch_patreon_login(rebuild=False)

    def _login_mouse_press(self, event):
        if event.button() == Qt.MouseButton.RightButton:
            self._launch_patreon_login(rebuild=True)
            event.accept()
            return
        self._login_button_base_mousePress(event)


    def hide_dropdown_timeout(self):
        """Hide the dropdown when the timer expires."""
        if self.dropdown_visible:
            self.tools_dropdown.hide_dropdown()
            self.dropdown_visible = False

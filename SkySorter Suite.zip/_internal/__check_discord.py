import socket
import ssl
import sys

def print_with_color(message, color):
    """Print colored messages in Windows command prompt."""
    colors = {
        'green': '2',
        'red': '4',
        'yellow': '6',
        'white': '7',
        'blue': '1'
    }
    
    color_code = colors.get(color, '7')  # Default to white
    
    # Windows command prompt color codes
    print(f"\033[3{color_code}m{message}\033[0m")

def test_ssl_protocols():
    """Test connection to Discord servers with different SSL protocols."""
    print("Testing connection to Discord with different SSL protocols...\n")
    
    # Test different SSL/TLS protocol versions
    protocols = [
        (ssl.PROTOCOL_TLS, "Default TLS"),
        (ssl.PROTOCOL_TLS_CLIENT, "TLS Client"),
        (ssl.PROTOCOL_TLSv1_2, "TLS 1.2"),
    ]
    
    # Try to import PROTOCOL_TLSv1_3 if available (Python 3.7+)
    try:
        protocols.append((ssl.PROTOCOL_TLSv1_3, "TLS 1.3"))
    except AttributeError:
        print_with_color("TLS 1.3 not available in your Python version", "yellow")

    success = False
    
    for protocol, name in protocols:
        print(f"\nTesting {name}:")
        try:
            context = ssl.SSLContext(protocol)
            context.verify_mode = ssl.CERT_REQUIRED
            context.check_hostname = True
            
            # Set modern cipher suites
            try:
                context.set_ciphers('HIGH:!aNULL:!eNULL:!EXPORT:!DES:!RC4:!MD5:!PSK:!SRP')
            except ssl.SSLError:
                # Some older Python versions might not support all these cipher options
                pass
                
            context.load_default_certs()
            
            with socket.create_connection(('discord.com', 443), timeout=10) as sock:
                with context.wrap_socket(sock, server_hostname='discord.com') as ssl_sock:
                    cipher = ssl_sock.cipher()
                    print_with_color(f"✓ SSL handshake successful using {name}", "green")
                    print_with_color(f"  - Cipher: {cipher[0]}", "white")
                    print_with_color(f"  - TLS Version: {cipher[1]}", "white")
                    print_with_color(f"  - Bits: {cipher[2]}", "white")
                    success = True
        except ssl.SSLError as e:
            print_with_color(f"✗ SSL Error with {name}: {e}", "red")
        except socket.error as e:
            print_with_color(f"✗ Socket Error with {name}: {e}", "red")
        except Exception as e:
            print_with_color(f"✗ Unexpected error with {name}: {e}", "red")
    
    print("\n-----------------------")
    if success:
        print_with_color("At least one SSL protocol version worked!", "green")
        print_with_color("Use the working protocol in your Discord bot code.", "green")
    else:
        print_with_color("All SSL protocol versions failed.", "red")
        print_with_color("This suggests a network/firewall issue blocking SSL connections.", "red")
    print("-----------------------")
    
    return success

def suggest_solutions():
    print("\n✨ TROUBLESHOOTING SUGGESTIONS ✨")
    
    print("\n1. Update your SSL certificates:")
    print("   Run this command: pip install --upgrade certifi")
    
    print("\n2. Check your firewall or antivirus:")
    print("   - Temporarily disable SSL scanning features")
    print("   - Add Python to the allowed applications list")
    print("   - Check for any rules blocking outbound 443 connections")
    
    print("\n3. If you're in China or a region with internet restrictions:")
    print("   - You may need to use a VPN to access Discord")
    print("   - Discord might be blocked at the network level")
    
    print("\n4. Check for corporate network restrictions:")
    print("   - Corporate networks often block gaming sites like Discord")
    print("   - You may need to request an exception or use another network")
    
    print("\n5. Try an alternative Discord library:")
    print("   - Some Discord libraries handle connection issues better")
    print("   - Consider disnake, nextcord, or discord.js (Node.js)")
    
    print("\n6. For your Bridge.py script specifics:")
    print("   - Add explicit SSL context configuration")
    print("   - Use the specific TLS version that worked in the tests")
    print("   - Add proper error handling for SSL connection issues")

if __name__ == "__main__":
    try:
        success = test_ssl_protocols()
        if not success:
            suggest_solutions()
    except Exception as e:
        print_with_color(f"An unexpected error occurred: {e}", "red")
        sys.exit(1)

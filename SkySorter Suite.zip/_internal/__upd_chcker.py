import argparse
import json
import re
import sys
import subprocess
from datetime import datetime
from pathlib import Path
import tkinter as tk
import webbrowser

import requests

# ---------------- CONFIG ---------------- #
OWNER = "Provarch"
REPO = "SkySorter-Suite"
BRANCH = "main"

COMMITS_API_URL = f"https://api.github.com/repos/{OWNER}/{REPO}/commits?sha={BRANCH}&per_page=10"
ZIP_RAW_URL = f"https://raw.githubusercontent.com/{OWNER}/{REPO}/{BRANCH}/SkySorter%20Suite.zip"

HEADERS = {
    "User-Agent": "Mozilla/5.0",
    "Accept": "application/vnd.github+json",
}

POPUP_OFFSET_X = 0
POPUP_OFFSET_Y = -100

button_style = {
    "bg": "#000000",
    "fg": "white",
    "font": ("Consolas", 10),
    "bd": 0,
    "relief": "flat",
    "activebackground": "#444444",
    "activeforeground": "white",
}

BORDER_COLOR = "#FFFFFF"
BG = "#000000"
HANDLE_BG = "#FFFFFF"
# ---------------------------------------- #


def _ver_key(v: str):
    v = str(v).strip()
    v = v[1:] if v.lower().startswith("v") else v
    parts = [p for p in v.split(".") if p != ""]
    return tuple(int(p) if p.isdigit() else 0 for p in parts)


def _normalize_ver_title(title: str) -> str:
    t = str(title).strip()
    t = t[1:] if t.lower().startswith("v") else t
    return t.strip()


def _bordered_inner(parent: tk.Toplevel, pad: int = 1) -> tk.Frame:
    border = tk.Frame(parent, bg=BORDER_COLOR)
    border.pack(fill="both", expand=True)

    inner = tk.Frame(border, bg=BG)
    inner.pack(fill="both", expand=True, padx=pad, pady=pad)
    return inner


def show_whats_new_popup(whats_new_content: str):
    w = tk.Toplevel()
    w.title("What's New")
    w.overrideredirect(True)
    w.attributes("-topmost", True)
    w.configure(bg=BORDER_COLOR)

    w.update_idletasks()
    width, height = 520, 360
    sw, sh = w.winfo_screenwidth(), w.winfo_screenheight()
    x = (sw - width) // 2 + POPUP_OFFSET_X
    y = (sh - height) // 2 + POPUP_OFFSET_Y
    w.geometry(f"{width}x{height}+{x}+{y}")

    w.bind("<Button-3>", lambda e: w.destroy())
    w.bind("<Escape>", lambda e: w.destroy())

    inner = _bordered_inner(w, pad=1)

    main_frame = tk.Frame(inner, bg=BG)
    main_frame.pack(fill="both", expand=True, padx=10, pady=10)

    top_frame = tk.Frame(main_frame, bg=BG)
    top_frame.pack(fill="x")

    close_button_top = tk.Button(
        top_frame,
        text="X",
        command=w.destroy,
        bg=BG,
        fg="white",
        font=("Consolas", 10),
        bd=0,
        activebackground="#444444",
        activeforeground="white",
    )
    close_button_top.pack(side=tk.RIGHT, padx=5, pady=5)

    text = tk.Text(main_frame, bg=BG, fg="white", font=("Consolas", 10), wrap="word", bd=0, highlightthickness=0)
    text.pack(fill="both", expand=True, pady=(0, 10))

    text.insert("1.0", whats_new_content)

    url_pattern = r"http[s]?://(?:[a-zA-Z]|[0-9]|[$-_@.&+]|[!*\\(\\),]|(?:%[0-9a-fA-F][0-9a-fA-F]))+"
    for match in re.finditer(url_pattern, whats_new_content):
        start_idx = f"1.0 + {match.start()}c"
        end_idx = f"1.0 + {match.end()}c"
        text.tag_add("link", start_idx, end_idx)
        text.tag_config("link", foreground="#66aaff", underline=True)
        text.tag_bind("link", "<Button-1>", lambda e, url=match.group(): webbrowser.open_new(url))

    text.config(state="disabled")

    resize_data = {"x": 0, "y": 0, "resizing": None, "width": width, "height": height}
    HANDLE_SIZE = 10

    br = tk.Frame(w, bg=HANDLE_BG, width=HANDLE_SIZE, height=HANDLE_SIZE, cursor="size_nw_se")
    bl = tk.Frame(w, bg=HANDLE_BG, width=HANDLE_SIZE, height=HANDLE_SIZE, cursor="size_ne_sw")
    tr = tk.Frame(w, bg=HANDLE_BG, width=HANDLE_SIZE, height=HANDLE_SIZE, cursor="size_ne_sw")
    tl = tk.Frame(w, bg=HANDLE_BG, width=HANDLE_SIZE, height=HANDLE_SIZE, cursor="size_nw_se")

    br.place(relx=1.0, rely=1.0, anchor="se")
    bl.place(relx=0.0, rely=1.0, anchor="sw")
    tr.place(relx=1.0, rely=0.0, anchor="ne")
    tl.place(relx=0.0, rely=0.0, anchor="nw")

    def start_resize(event, corner):
        resize_data["x"] = event.x_root
        resize_data["y"] = event.y_root
        resize_data["resizing"] = corner

    def stop_resize(event):
        resize_data["resizing"] = None

    def resize(event):
        if not resize_data["resizing"]:
            return

        dx = event.x_root - resize_data["x"]
        dy = event.y_root - resize_data["y"]

        new_w = resize_data["width"]
        new_h = resize_data["height"]
        new_x = w.winfo_x()
        new_y = w.winfo_y()

        if resize_data["resizing"] in ("br", "tr"):
            new_w = max(260, resize_data["width"] + dx)
        if resize_data["resizing"] in ("bl", "tl"):
            new_w = max(260, resize_data["width"] - dx)
            new_x += dx
        if resize_data["resizing"] in ("br", "bl"):
            new_h = max(200, resize_data["height"] + dy)
        if resize_data["resizing"] in ("tr", "tl"):
            new_h = max(200, resize_data["height"] - dy)
            new_y += dy

        resize_data["width"] = new_w
        resize_data["height"] = new_h
        resize_data["x"] = event.x_root
        resize_data["y"] = event.y_root

        w.geometry(f"{int(new_w)}x{int(new_h)}+{int(new_x)}+{int(new_y)}")

    for h, corner in ((br, "br"), (bl, "bl"), (tr, "tr"), (tl, "tl")):
        h.bind("<Button-1>", lambda e, c=corner: start_resize(e, c))
        h.bind("<ButtonRelease-1>", stop_resize)
        h.bind("<B1-Motion>", resize)

    drag_data = {"x": 0, "y": 0, "dragging": False}

    def start_drag(event):
        drag_data["x"] = event.x
        drag_data["y"] = event.y
        drag_data["dragging"] = True

    def stop_drag(event):
        drag_data["dragging"] = False

    def drag(event):
        if drag_data["dragging"]:
            x2 = w.winfo_x() + (event.x - drag_data["x"])
            y2 = w.winfo_y() + (event.y - drag_data["y"])
            w.geometry(f"+{x2}+{y2}")

    w.bind("<Button-1>", start_drag)
    w.bind("<ButtonRelease-1>", stop_drag)
    w.bind("<B1-Motion>", drag)


def show_custom_popup(latest_ver: str, zip_url: str, local_path: Path, whats_new_content: str, ui_pid: int):
    root = tk.Tk()
    root.withdraw()

    popup = tk.Toplevel()
    popup.title("Update Available")
    popup.overrideredirect(True)
    popup.attributes("-topmost", True)
    popup.configure(bg=BORDER_COLOR)

    popup.update_idletasks()
    width, height = 320, 130
    sw, sh = popup.winfo_screenwidth(), popup.winfo_screenheight()
    x = (sw - width) // 2
    y = (sh - height) // 2 + POPUP_OFFSET_Y
    popup.geometry(f"{width}x{height}+{x}+{y}")

    popup.bind("<Button-3>", lambda e: (popup.destroy(), root.quit()))
    popup.bind("<Escape>", lambda e: (popup.destroy(), root.quit()))

    inner = _bordered_inner(popup, pad=1)

    drag_data = {"x": 0, "y": 0, "dragging": False}

    frame = tk.Frame(inner, bg=BG)
    frame.grid(row=0, column=0, sticky="nsew")

    inner.grid_rowconfigure(0, weight=1)
    inner.grid_columnconfigure(0, weight=1)
    frame.grid_rowconfigure(0, weight=1)
    frame.grid_rowconfigure(1, weight=1)
    frame.grid_columnconfigure(0, weight=1)

    label = tk.Label(frame, text=f"Update v{latest_ver} available!", bg=BG, fg="white", font=("Consolas", 10))
    label.grid(row=0, column=0, pady=(10, 5), sticky="ew")

    btn_frame = tk.Frame(frame, bg=BG)
    btn_frame.grid(row=1, column=0, pady=(0, 10), sticky="ew")

    btn_frame.grid_columnconfigure(0, weight=1)
    btn_frame.grid_columnconfigure(1, weight=1)
    btn_frame.grid_columnconfigure(2, weight=1)

    def update_action():
        try:
            cmd = [
                sys.executable,
                "__upd_dloader.py",
                zip_url,
                str(local_path),
                "--requested-ver",
                str(latest_ver),
            ]
            if ui_pid:
                cmd += ["--ui-pid", str(ui_pid)]
            cmd += ["--pause", "1.5"]  # let you see/copy console lines

            print("[checker] Starting download...", flush=True)
            proc = subprocess.run(cmd, check=False)
            print(f"[checker] Downloader exited with code {proc.returncode}", flush=True)
        except Exception as e:
            print(f"[checker] Download failed: {e}", flush=True)

        popup.destroy()
        root.quit()

    def cancel_action():
        print("[checker] Update cancelled.", flush=True)
        popup.destroy()
        root.quit()

    def whats_new_action():
        show_whats_new_popup(whats_new_content)

    tk.Button(btn_frame, text="Update", command=update_action, **button_style).grid(row=0, column=0, padx=5, sticky="e")
    tk.Button(btn_frame, text="What's New", command=whats_new_action, **button_style).grid(row=0, column=1, padx=5)
    tk.Button(btn_frame, text="Cancel", command=cancel_action, **button_style).grid(row=0, column=2, padx=5, sticky="w")

    def start_drag(event):
        drag_data["x"] = event.x
        drag_data["y"] = event.y
        drag_data["dragging"] = True

    def stop_drag(event):
        drag_data["dragging"] = False

    def drag(event):
        if drag_data["dragging"]:
            x2 = popup.winfo_x() + (event.x - drag_data["x"])
            y2 = popup.winfo_y() + (event.y - drag_data["y"])
            popup.geometry(f"+{x2}+{y2}")

    popup.bind("<Button-1>", start_drag)
    popup.bind("<ButtonRelease-1>", stop_drag)
    popup.bind("<B1-Motion>", drag)

    root.mainloop()


def get_current_version(ver_file: Path) -> str:
    try:
        data = json.loads(ver_file.read_text(encoding="utf-8"))
        return str(data.get("curr_ver", "0")).strip()
    except Exception as e:
        print(f"[checker] Error reading version file: {e}", flush=True)
        return "0"


def fetch_commits():
    r = requests.get(COMMITS_API_URL, headers=HEADERS, timeout=15)
    r.raise_for_status()
    return r.json()


def format_whats_new(commits) -> tuple[str, str]:
    lines = []
    latest_ver = "0"

    for idx, c in enumerate(commits):
        commit = c.get("commit", {}) or {}
        msg = (commit.get("message") or "").strip()
        if not msg:
            continue

        title = msg.splitlines()[0].strip()
        title = _normalize_ver_title(title) or "?"

        if idx == 0:
            latest_ver = title

        body = "\n".join(msg.splitlines()[1:]).strip()
        if not body:
            body = "(no details)"

        date_str = ""
        try:
            d = (commit.get("author") or {}).get("date") or (commit.get("committer") or {}).get("date")
            if d:
                dt = datetime.fromisoformat(d.replace("Z", "+00:00"))
                date_str = dt.strftime("%Y-%m-%d")
        except Exception:
            date_str = ""

        header = f"v{title}---------------------------------------{date_str}".rstrip()
        lines.append(header)
        lines.append(body)
        lines.append("")

    return latest_ver, "\n".join(lines).rstrip() + "\n"


def check_for_updates(ui_pid: int):
    script_dir = Path(__file__).resolve().parent
    version_file = script_dir / "curr.ver"

    curr_ver = get_current_version(version_file)
    curr_key = _ver_key(curr_ver)

    try:
        commits = fetch_commits()
        latest_ver, whats_new = format_whats_new(commits)
        latest_key = _ver_key(latest_ver)

        if latest_key > curr_key:
            local_path = script_dir / "SkySorter Suite.zip"
            show_custom_popup(latest_ver, ZIP_RAW_URL, local_path, whats_new, ui_pid=ui_pid)
        else:
            print(f"[checker] Scripts all up to date. (v{curr_ver})", flush=True)
    except Exception as e:
        print(f"[checker] Failed update check: {e}", flush=True)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--ui-pid", type=int, default=0)
    args = ap.parse_args()
    check_for_updates(ui_pid=args.ui_pid)


if __name__ == "__main__":
    main()

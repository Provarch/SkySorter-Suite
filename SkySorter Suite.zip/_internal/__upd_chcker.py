import requests
import re
import json
import sys
import subprocess
from pathlib import Path
import tkinter as tk
import webbrowser

# ---------------- CONFIG ---------------- #
OWNER = "Provarch"
REPO = "SkySorter-Suite"
BRANCH = "main"

COMMIT_LATEST_URL = f"https://api.github.com/repos/{OWNER}/{REPO}/commits/{BRANCH}"
COMMITS_LIST_URL = f"https://api.github.com/repos/{OWNER}/{REPO}/commits?sha={BRANCH}&per_page=10"

ZIP_REPO_NAME = "SkySorter Suite.zip"
ZIP_URL = f"https://raw.githubusercontent.com/{OWNER}/{REPO}/{BRANCH}/{ZIP_REPO_NAME.replace(' ', '%20')}"
LOCAL_ZIP_NAME = "SkySorter Suite.zip"

HEADERS = {
    "User-Agent": "Mozilla/5.0",
    "Accept": "application/vnd.github+json",
}

POPUP_OFFSET_X = 0
POPUP_OFFSET_Y = -100
# ---------------------------------------- #

button_style = {
    "bg": "#000000",
    "fg": "white",
    "font": ("Consolas", 10),
    "bd": 0,
    "relief": "flat",
    "activebackground": "#444444",
    "activeforeground": "white"
}

def _get_flag_value(flag: str):
    if flag in sys.argv:
        i = sys.argv.index(flag)
        if i + 1 < len(sys.argv):
            return sys.argv[i + 1]
    return None

def _ver_key(v: str):
    v = str(v).strip()
    parts = [p for p in v.split(".") if p != ""]
    return tuple(int(p) if p.isdigit() else 0 for p in parts)

def _split_commit_message(msg: str):
    msg = (msg or "").rstrip()
    lines = msg.splitlines()
    title = lines[0].strip() if lines else ""
    body = "\n".join(lines[1:]).strip() if len(lines) > 1 else ""
    return title, body

def _format_commits_for_whats_new(commits):
    # Desired format:
    # v1.22---------------------------------------YYYY-MM-DD
    # body...
    out = []
    for c in commits:
        title = (c.get("title") or "").strip()
        body = (c.get("body") or "").strip()
        date = (c.get("date") or "")[:10]

        version = f"v{title}" if title else "v?"
        left = f"{version}"
        # make a fixed-ish line
        line = left + "-" * max(3, 50 - len(left))
        if date:
            line += date

        out.append(line)
        if body:
            out.append(body)
        out.append("")

    return "\n".join(out).rstrip()

def show_whats_new_popup(whats_new_content):
    whats_new_popup = tk.Toplevel()
    whats_new_popup.title("What's New")
    whats_new_popup.overrideredirect(True)
    whats_new_popup.attributes("-topmost", True)
    whats_new_popup.configure(bg="#000000")

    whats_new_popup.update_idletasks()
    width = 520
    height = 380
    screen_width = whats_new_popup.winfo_screenwidth()
    screen_height = whats_new_popup.winfo_screenheight()
    x = (screen_width - width) // 2 + POPUP_OFFSET_X
    y = (screen_height - height) // 2 + POPUP_OFFSET_Y
    whats_new_popup.geometry(f"{width}x{height}+{x}+{y}")

    main_frame = tk.Frame(whats_new_popup, bg="#000000")
    main_frame.pack(fill="both", expand=True, padx=10, pady=10)

    top_frame = tk.Frame(main_frame, bg="#000000")
    top_frame.pack(fill="x")

    close_button_top = tk.Button(
        top_frame, text="X", command=whats_new_popup.destroy,
        bg="#000000", fg="white", font=("Consolas", 10), bd=0
    )
    close_button_top.pack(side=tk.RIGHT, padx=5, pady=5)

    text = tk.Text(main_frame, bg="#000000", fg="white", font=("Consolas", 10), wrap="word")
    text.pack(fill="both", expand=True, pady=(0, 10))
    text.insert("1.0", whats_new_content)

    url_pattern = r'http[s]?://(?:[a-zA-Z]|[0-9]|[$-_@.&+]|[!*\\(\\),]|(?:%[0-9a-fA-F][0-9a-fA-F]))+'
    for match in re.finditer(url_pattern, whats_new_content):
        start_idx = f"1.0 + {match.start()}c"
        end_idx = f"1.0 + {match.end()}c"
        text.tag_add("link", start_idx, end_idx)
        text.tag_config("link", foreground="blue", underline=True)
        text.tag_bind("link", "<Button-1>", lambda e, url=match.group(): webbrowser.open_new(url))

    text.config(state="disabled")

    # drag
    drag_data = {"x": 0, "y": 0, "dragging": False}

    def start_drag(event):
        drag_data["x"] = event.x
        drag_data["y"] = event.y
        drag_data["dragging"] = True

    def stop_drag(event):
        drag_data["dragging"] = False

    def drag(event):
        if drag_data["dragging"]:
            x2 = whats_new_popup.winfo_x() + (event.x - drag_data["x"])
            y2 = whats_new_popup.winfo_y() + (event.y - drag_data["y"])
            whats_new_popup.geometry(f"+{x2}+{y2}")

    whats_new_popup.bind("<Button-1>", start_drag)
    whats_new_popup.bind("<ButtonRelease-1>", stop_drag)
    whats_new_popup.bind("<B1-Motion>", drag)

def get_current_version(ver_file):
    try:
        with open(ver_file, 'r', encoding='utf-8') as f:
            data = json.load(f)
            return str(data["curr_ver"]).strip()
    except Exception as e:
        print(f"Error reading version file: {e}", flush=True)
        sys.exit(1)

def _fetch_commits(max_count=10):
    r = requests.get(COMMITS_LIST_URL, headers=HEADERS, timeout=10)
    r.raise_for_status()
    items = r.json() or []
    commits = []
    for it in items[:max_count]:
        commit_obj = (it.get("commit") or {})
        msg = (commit_obj.get("message") or "")
        title, body = _split_commit_message(msg)
        sha = it.get("sha") or ""
        url = it.get("html_url") or ""
        date = ((commit_obj.get("author") or {}).get("date") or "")
        commits.append({"title": title, "body": body, "sha": sha, "url": url, "date": date})
    return commits

def show_custom_popup(latest_ver, zip_url, local_path, whats_new_content, ui_pid=None):
    root = tk.Tk()
    root.withdraw()

    popup = tk.Toplevel()
    popup.title("Update Available")
    popup.overrideredirect(True)
    popup.attributes("-topmost", True)
    popup.configure(bg="#000000")

    popup.update_idletasks()
    width = 300
    height = 120
    screen_width = popup.winfo_screenwidth()
    screen_height = popup.winfo_screenheight()
    x = (screen_width - width) // 2 + POPUP_OFFSET_X
    y = (screen_height - height) // 2 + POPUP_OFFSET_Y
    popup.geometry(f"{width}x{height}+{x}+{y}")

    # IMPORTANT: make the popup's grid expand so content can be centered
    popup.grid_rowconfigure(0, weight=1)
    popup.grid_columnconfigure(0, weight=1)

    frame = tk.Frame(popup, bg="#000000")
    frame.grid(row=0, column=0, sticky="nsew")

    # IMPORTANT: make the frame grid expand and allow true centering
    frame.grid_rowconfigure(0, weight=1)
    frame.grid_rowconfigure(1, weight=1)
    frame.grid_columnconfigure(0, weight=1)

    label = tk.Label(
        frame,
        text=f"Update v{latest_ver} available!",
        bg="#000000",
        fg="white",
        font=("Consolas", 10),
        justify="center",
        anchor="center",
    )
    # Center the label in its cell
    label.grid(row=0, column=0, pady=(6, 2), sticky="n")

    btn_frame = tk.Frame(frame, bg="#000000")
    btn_frame.grid(row=1, column=0, pady=(0, 6), sticky="n")

    # Keep buttons evenly spaced
    btn_frame.grid_columnconfigure(0, weight=1)
    btn_frame.grid_columnconfigure(1, weight=1)
    btn_frame.grid_columnconfigure(2, weight=1)

    def update_action():
        try:
            print("[checker] Starting download...", flush=True)

            # PID WORKFLOW PRESERVED HERE
            args = [sys.executable, "__upd_dloader.py", zip_url, str(local_path), str(latest_ver)]
            if ui_pid:
                args += ["--ui-pid", str(ui_pid)]

            proc = subprocess.Popen(
                args,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                bufsize=1,
            )

            if proc.stdout:
                for line in proc.stdout:
                    print("[dloader] " + line.rstrip("\n"), flush=True)

            code = proc.wait()
            print(f"[checker] Downloader exited with code {code}", flush=True)

        except Exception as e:
            print(f"[checker] Download failed: {e}", flush=True)

        popup.destroy()
        root.quit()

    def cancel_action():
        print("[checker] Update cancelled.", flush=True)
        popup.destroy()
        root.quit()

    def whats_new_action():
        show_whats_new_popup(whats_new_content)

    tk.Button(btn_frame, text="Update", command=update_action, **button_style).grid(row=0, column=0, padx=8, sticky="e")
    tk.Button(btn_frame, text="What's New", command=whats_new_action, **button_style).grid(row=0, column=1, padx=8)
    tk.Button(btn_frame, text="Cancel", command=cancel_action, **button_style).grid(row=0, column=2, padx=8, sticky="w")

    # Drag support
    drag_data = {"x": 0, "y": 0, "dragging": False}

    def start_drag(event):
        drag_data["x"] = event.x
        drag_data["y"] = event.y
        drag_data["dragging"] = True

    def stop_drag(event):
        drag_data["dragging"] = False

    def drag(event):
        if drag_data["dragging"]:
            x2 = popup.winfo_x() + (event.x - drag_data["x"])
            y2 = popup.winfo_y() + (event.y - drag_data["y"])
            popup.geometry(f"+{x2}+{y2}")

    popup.bind("<Button-1>", start_drag)
    popup.bind("<ButtonRelease-1>", stop_drag)
    popup.bind("<B1-Motion>", drag)

    root.mainloop()


def check_for_updates():
    ui_pid = _get_flag_value("--ui-pid")

    script_dir = Path(__file__).parent
    version_file = script_dir / "curr.ver"

    curr_ver_str = get_current_version(version_file)
    curr_ver_key = _ver_key(curr_ver_str)

    r = requests.get(COMMIT_LATEST_URL, headers=HEADERS, timeout=10)
    r.raise_for_status()
    data = r.json()
    msg = (data.get("commit", {}).get("message") or "")
    latest_ver_str, _latest_body = _split_commit_message(msg)
    latest_ver_key = _ver_key(latest_ver_str)

    if latest_ver_key <= curr_ver_key:
        print(f"\nScripts all up to date. (v{curr_ver_str})", flush=True)
        return

    commits = _fetch_commits(max_count=10)
    whats_new_content = _format_commits_for_whats_new(commits) if commits else "Unable to load commit history."

    local_path = script_dir / LOCAL_ZIP_NAME
    show_custom_popup(latest_ver_str, ZIP_URL, local_path, whats_new_content, ui_pid=ui_pid)

if __name__ == "__main__":
    check_for_updates()

import argparse
import sys
from pathlib import Path

import requests
import subprocess


def log(msg: str) -> None:
    print(f"[dloader] {msg}", flush=True)


def download_zip(zip_url: str, local_path: Path) -> None:
    local_path.parent.mkdir(parents=True, exist_ok=True)

    log(f"Downloading ZIP from:\n{zip_url}")
    log(f"Saving to (overwrite): {local_path}")

    with requests.get(zip_url, stream=True, timeout=60) as r:
        r.raise_for_status()
        total = int(r.headers.get("Content-Length", "0") or 0)

        written = 0
        chunk_size = 1024 * 256  # 256KB

        with open(local_path, "wb") as f:
            for chunk in r.iter_content(chunk_size=chunk_size):
                if not chunk:
                    continue
                f.write(chunk)
                written += len(chunk)

                if total:
                    pct = int((written / total) * 100)
                    if pct % 10 == 0:
                        log(f"Download progress: {pct}%")

        log(f"Downloaded update to: {local_path}")
        log(f"Done. Wrote {written} bytes.")


def run_updater(updater_path: Path, ui_pid: int, requested_ver: str, zip_path: Path, pause: float) -> int:
    cmd = [
        sys.executable,
        str(updater_path),
        "--zip", str(zip_path),
    ]
    if requested_ver:
        cmd += ["--requested-ver", requested_ver]
    if ui_pid:
        cmd += ["--ui-pid", str(ui_pid)]
    if pause and pause > 0:
        cmd += ["--pause", str(pause)]

    log("Starting __updater.py")
    proc = subprocess.Popen(
        cmd,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        bufsize=1,
    )

    assert proc.stdout is not None
    for line in proc.stdout:
        line = line.rstrip("\n")
        if line:
            print(f"[dloader] {line}", flush=True)

    return proc.wait()


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("zip_url")
    ap.add_argument("local_path")
    ap.add_argument("--ui-pid", type=int, default=0)
    ap.add_argument("--requested-ver", type=str, default="")
    ap.add_argument("--pause", type=float, default=0.0)
    args = ap.parse_args()

    zip_url = args.zip_url.strip()
    local_path = Path(args.local_path).expanduser()

    download_zip(zip_url, local_path)

    script_dir = Path(__file__).resolve().parent
    updater_path = script_dir / "__updater.py"
    if not updater_path.exists():
        log(f"Error: __updater.py not found at {updater_path}")
        return 2

    code = run_updater(
        updater_path=updater_path,
        ui_pid=args.ui_pid,
        requested_ver=args.requested_ver.strip(),
        zip_path=local_path.resolve(),
        pause=args.pause,
    )
    log(f"__updater.py exited with code {code}")
    return code


if __name__ == "__main__":
    raise SystemExit(main())

import sys
import requests
import tkinter as tk
from tkinter import ttk
from pathlib import Path
import threading
import os
import time
import subprocess

def _get_flag_value(flag: str):
    if flag in sys.argv:
        i = sys.argv.index(flag)
        if i + 1 < len(sys.argv):
            return sys.argv[i + 1]
    return None

def download_with_progress(zip_url, local_path: Path):
    root = tk.Tk()
    root.title("Downloading Update")
    root.overrideredirect(True)
    root.attributes("-topmost", True)
    root.configure(bg="#000000")

    root.update_idletasks()
    width = 300
    height = 100
    screen_width = root.winfo_screenwidth()
    screen_height = root.winfo_screenheight()
    x = (screen_width - width) // 2
    y = (screen_height - height) // 2
    root.geometry(f"{width}x{height}+{x}+{y}")

    main_frame = tk.Frame(root, bg="#000000")
    main_frame.pack(fill="both", expand=True, padx=10, pady=10)

    label = tk.Label(main_frame, text="Downloading update...", bg="#000000", fg="white", font=("Consolas", 10))
    label.pack(pady=(0, 10))

    style = ttk.Style()
    style.configure("Custom.Horizontal.TProgressbar", background="limegreen", troughcolor="#000000")
    progress = ttk.Progressbar(main_frame, style="Custom.Horizontal.TProgressbar", length=200, mode="determinate")
    progress.pack(pady=(0, 10))

    def download():
        tmp_path = local_path.with_suffix(local_path.suffix + ".tmp")
        try:
            with requests.get(zip_url, stream=True, timeout=30) as r:
                r.raise_for_status()
                total_size = int(r.headers.get("content-length", 0))
                chunk_size = 1024 * 256
                downloaded = 0

                with open(tmp_path, "wb") as f:
                    for chunk in r.iter_content(chunk_size=chunk_size):
                        if chunk:
                            f.write(chunk)
                            downloaded += len(chunk)
                            if total_size > 0:
                                progress["value"] = (downloaded / total_size) * 100
                                root.update_idletasks()

            os.replace(tmp_path, local_path)
            print(f"Downloaded update to: {local_path}", flush=True)

        except Exception as e:
            print(f"Download failed: {e}", flush=True)
            try:
                if tmp_path.exists():
                    tmp_path.unlink()
            except Exception:
                pass
        finally:
            root.destroy()

    threading.Thread(target=download, daemon=True).start()

    drag_data = {"x": 0, "y": 0, "dragging": False}

    def start_drag(event):
        drag_data["x"] = event.x
        drag_data["y"] = event.y
        drag_data["dragging"] = True

    def stop_drag(event):
        drag_data["dragging"] = False

    def drag(event):
        if drag_data["dragging"]:
            x2 = root.winfo_x() + (event.x - drag_data["x"])
            y2 = root.winfo_y() + (event.y - drag_data["y"])
            root.geometry(f"+{x2}+{y2}")

    root.bind("<Button-1>", start_drag)
    root.bind("<ButtonRelease-1>", stop_drag)
    root.bind("<B1-Motion>", drag)

    root.mainloop()

if __name__ == "__main__":
    if len(sys.argv) < 3:
        print("Usage: __upd_dloader.py <zip_url> <local_path> [new_version] [--ui-pid PID]", flush=True)
        sys.exit(1)

    zip_url = sys.argv[1]
    local_path = Path(sys.argv[2])

    new_version = ""
    if len(sys.argv) >= 4 and not sys.argv[3].startswith("--"):
        new_version = sys.argv[3]

    ui_pid = _get_flag_value("--ui-pid")

    download_with_progress(zip_url, local_path)

    script_dir = os.path.dirname(os.path.abspath(__file__))
    updater_path = os.path.join(script_dir, "__updater.py")

    if not os.path.exists(updater_path):
        print(f"Error: __updater.py not found at {updater_path}", flush=True)
        sys.exit(1)

    print("Starting __updater.py", flush=True)
    time.sleep(0.5)

    try:
        args = [sys.executable, updater_path, str(local_path)]
        if new_version:
            args.append(str(new_version))
        if ui_pid:
            args += ["--ui-pid", str(ui_pid)]

        proc = subprocess.Popen(
            args,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            bufsize=1,
            cwd=script_dir
        )

        if proc.stdout:
            for line in proc.stdout:
                print("[updater] " + line.rstrip("\n"), flush=True)

        code = proc.wait()
        print(f"__updater.py exited with code {code}", flush=True)

    except Exception as e:
        print(f"Failed to launch/run __updater.py: {e}", flush=True)
        sys.exit(1)

    sys.exit(0)

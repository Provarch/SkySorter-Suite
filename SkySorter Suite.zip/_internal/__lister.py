import sys
import os
import re
import json
import logging
import hashlib
from collections import defaultdict
from PIL import Image

# Setup logging
script_dir = os.path.dirname(os.path.abspath(__file__))
log_file = os.path.join(script_dir, "lister.log")
logging.basicConfig(
    level=logging.DEBUG,
    format="%(asctime)s - %(levelname)s - %(message)s",
    handlers=[logging.FileHandler(log_file, mode="w", encoding="utf-8")]
)
logger = logging.getLogger(__name__)

# Global variables
metadata_read_count = 0
user_uid = None
archive_extensions = {".zip", ".rar", ".7z"}
image_extensions = {".jpg", ".jpeg", ".png"}
sky_regex = r"(\d{2,8}\.\w{12,13})"

def load_config():
    """Load configuration from sssuite.cfg."""
    global user_uid
    config_path = os.path.join(script_dir, "sssuite.cfg")
    try:
        with open(config_path, "r", encoding="utf-8") as f:
            config = json.load(f)
            user_uid = config.get("user_uid", "default_uid")
            source_folder = config.get("3dsky_folder", "")
            if not source_folder:
                logger.warning(f"No 3dsky_folder specified in {config_path}")
            elif not os.path.isdir(source_folder):
                logger.warning(f"3dsky_folder in {config_path} is not a valid directory: {source_folder}")
                source_folder = ""
            logger.info(f"Loaded user_uid: {user_uid} and 3dsky_folder: {source_folder} from {config_path}")
            return source_folder
    except FileNotFoundError:
        logger.error(f"Configuration file not found: {config_path}")
        print(f"Error: Configuration file not found: {config_path}. Please create sssuite.cfg with 3dsky_folder and user_uid.", flush=True)
        return ""
    except Exception as e:
        logger.error(f"Error reading {config_path}: {str(e)}")
        print(f"Error reading {config_path}: {str(e)}", flush=True)
        return ""

def read_xmp_and_exif_data(file_path):
    """Read XMP and EXIF metadata from an image, replacing hyphens in model title."""
    global metadata_read_count
    metadata_read_count += 1
    logger.info(f"Reading metadata from image: {file_path} (Metadata read #{metadata_read_count})")
    try:
        with Image.open(file_path) as img:
            img.load()
            xmp_data = img.getxmp()
            title = None
            if "xmpmeta" in xmp_data and "RDF" in xmp_data["xmpmeta"]:
                rdf = xmp_data["xmpmeta"]["RDF"]
                if "Description" in rdf:
                    desc = rdf["Description"]
                    if isinstance(desc, dict) and "title" in desc:
                        title_data = desc["title"]
                        if isinstance(title_data, dict) and "Alt" in title_data:
                            title = title_data["Alt"].get("li", {}).get("text")

            xp_subject = None
            exif_data = img.getexif()
            for tag, value in exif_data.items():
                logger.debug(f"tag: {tag} - type: {type(value)} - value: {value}")
            if 0x9c9f in exif_data:
                subject_raw = exif_data[0x9c9f]
                if isinstance(subject_raw, tuple):
                    xp_subject = bytes(subject_raw).decode("utf-16", errors="ignore").rstrip("\x00")
                elif isinstance(subject_raw, bytes):
                    xp_subject = subject_raw.decode("utf-16", errors="ignore").rstrip("\x00")
                else:
                    xp_subject = str(subject_raw)

            artist = None
            if 0x13b in exif_data:
                artist_raw = exif_data[0x13b]
                if isinstance(artist_raw, bytes):
                    artist = artist_raw.decode("utf-8", errors="ignore")
                elif isinstance(artist_raw, str):
                    artist = artist_raw

            if title and xp_subject:
                actual_id_match = re.search(sky_regex, xp_subject)
                actual_id = actual_id_match.group(1) if actual_id_match else None
                title_parts = [part.strip() for part in title.split("|")]
                if len(title_parts) >= 3:
                    # Replace hyphens in model title with en-dash (–)
                    model_title = title_parts[0].replace("-", "–")
                    subcategory = title_parts[-2]
                    category = title_parts[-1]
                    padded_actual_id = f"{actual_id: <21}"
                    is_pro = "ProSky" in artist if artist else False
                    formatted_line = f"{padded_actual_id} - {model_title} | {subcategory} | {category}"
                    logger.info(f"Successfully extracted metadata for {file_path}: ID={actual_id}, Title={model_title}, Pro={is_pro}")
                    return formatted_line, is_pro, actual_id
            logger.warning(f"No valid metadata found for {file_path}")
            return None, None, None
    except Exception as e:
        logger.error(f"Error processing {file_path}: {str(e)}")
        print(f"Error processing {file_path}: {str(e)}", flush=True)
        return None, None, None



def verify_existing_report(output_file, paths_file):
    """Verify the integrity of an existing report file using the hash in [hash_container]."""
    logger.info(f"Verifying report: {output_file}")
    if not os.path.exists(output_file):
        logger.info(f"No report file exists at {output_file}. Starting fresh.")
        return True

    try:
        container_lines = []
        stored_hash = None
        in_container = False
        in_hash_container = False

        with open(output_file, "r", encoding="utf-8") as f:
            lines = f.readlines()
            logger.debug(f"Read {len(lines)} lines from {output_file}")
            for line in lines:
                line = line.rstrip("\n")
                if line == f"[{user_uid}]":
                    in_container = True
                    continue
                elif line == f"[/{user_uid}]":
                    in_container = False
                    continue
                elif line == "[hash_container]":
                    in_hash_container = True
                    continue
                elif line == "[/hash_container]":
                    in_hash_container = False
                    continue
                if in_container:
                    container_lines.append(line + "\n")
                elif in_hash_container and line.strip():
                    stored_hash = line.strip()

        if container_lines and stored_hash:
            container_content = "".join(container_lines)
            content_bytes = container_content.encode("utf-8")
            computed_hash = hashlib.sha512(content_bytes).hexdigest()
            if computed_hash != stored_hash:
                logger.error(f"Integrity verification failed. Computed Hash: {computed_hash}, Stored Hash: {stored_hash}")
                print(f"Warning: Integrity verification failed for {output_file}. Will overwrite report.", flush=True)
                return False
            logger.info(f"Integrity verification passed for {output_file}.")
            print(f"Integrity verification passed for {output_file}.", flush=True)
            return True
        else:
            logger.warning(f"Missing [{user_uid}] or [hash_container] in {output_file}. Assuming older version or tampered.")
            print(f"Warning: Invalid report format in {output_file}. Will overwrite report.", flush=True)
            return False
    except Exception as e:
        logger.error(f"Error verifying {output_file}: {str(e)}")
        print(f"Warning: Error verifying {output_file}. Will overwrite report: {str(e)}.", flush=True)
        return False

def parse_supposed_contents(output_file, paths_file):
    """Parse the report to generate supposed_contents with model details and quoted file paths."""
    logger.info(f"Parsing supposed contents from: {output_file} and paths from: {paths_file}")
    supposed_contents = []
    model_id_to_entry = {}
    identifiable_model_ids = set()
    unrecognized_models = set()

    if not os.path.exists(output_file):
        logger.info(f"No existing report found at {output_file}")
        return supposed_contents, model_id_to_entry, identifiable_model_ids, unrecognized_models

    # Parse main metadata file
    in_meta_container = False
    with open(output_file, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line or line in [f"[{user_uid}]", f"[/{user_uid}]", "[hash_container]", "[/hash_container]"]:
                if line == f"[{user_uid}]":
                    in_meta_container = True
                elif line == f"[/{user_uid}]":
                    in_meta_container = False
                continue
            if in_meta_container and line:
                # Split on " - " but ensure proper handling of model_id
                parts = line.split(" - ", 2)
                if len(parts) >= 3:
                    model_id_match = re.search(sky_regex, parts[0])
                    if model_id_match:
                        model_id = model_id_match.group(1)
                        model_type = parts[1].strip()
                        model_desc = parts[2].strip()
                        desc_parts = [part.strip() for part in model_desc.split("|")]
                        if len(desc_parts) >= 3:
                            # Restore en-dash to hyphen if needed, or keep as is
                            model_name = desc_parts[0].replace("–", "-")
                            subcategory = desc_parts[-2]
                            category = desc_parts[-1]
                        else:
                            model_name = model_desc.replace("–", "-")
                            subcategory = "Unknown"
                            category = "Unknown"
                            logger.warning(f"Incomplete metadata for {model_id}: {model_desc}. Using fallback: {model_name} | {subcategory} | {category}")
                        is_pro = model_type.lower() == "pro"
                        line_content = f"{model_id: <21} - {model_desc}"
                        entry = {
                            "model_id": model_id,
                            "model_name": model_name,
                            "subcategory": subcategory,
                            "category": category,
                            "is_pro": is_pro,
                            "line": line_content,
                            "archive_ext": None,
                            "archive_path": "",
                            "image_path": ""
                        }
                        supposed_contents.append(entry)
                        model_id_to_entry[model_id] = entry
                        identifiable_model_ids.add(model_id)
                        logger.debug(f"Parsed supposed content: {model_id} ({model_name})")
                    else:
                        logger.warning(f"Skipping identifiable model with invalid model_id: {line}")
                else:
                    logger.warning(f"Skipping malformed identifiable model entry: {line}")

    # Parse paths file if it exists
    if os.path.exists(paths_file):
        in_paths_container = False
        with open(paths_file, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line or line in [f"[{user_uid}]", f"[/{user_uid}]"]:
                    if line == f"[{user_uid}]":
                        in_paths_container = True
                    elif line == f"[/{user_uid}]":
                        in_paths_container = False
                    continue
                if in_paths_container and line:
                    parts = line.split(": ", 1)
                    if len(parts) == 2:
                        model_id = parts[0].strip()
                        path_part = parts[1].strip()
                        # Match quoted paths: "<path>", "<path>"
                        path_match = re.match(r'"([^"]+)",\s*"([^"]+)"', path_part)
                        if path_match and model_id in model_id_to_entry:
                            archive_path = path_match.group(1)
                            image_path = path_match.group(2)
                            model_id_to_entry[model_id]["archive_path"] = archive_path
                            model_id_to_entry[model_id]["image_path"] = image_path
                            model_id_to_entry[model_id]["archive_ext"] = os.path.splitext(archive_path)[1]
                            logger.debug(f"Parsed paths for {model_id}: archive={archive_path}, image={image_path}")
                        else:
                            logger.warning(f"Skipping invalid paths entry: {line}")
                    else:
                        logger.warning(f"Skipping malformed paths entry: {line}")

    logger.info(f"Parsed {len(supposed_contents)} supposed contents, {len(unrecognized_models)} unrecognized models")
    logger.debug(f"Identifiable model IDs: {identifiable_model_ids}")
    return supposed_contents, model_id_to_entry, identifiable_model_ids, unrecognized_models



def get_subfolders(source_folder):
    """Get all subfolders recursively."""
    logger.info(f"Scanning for subfolders in: {source_folder}")
    subfolders = []
    for root, dirs, _ in os.walk(source_folder):
        for dir_name in dirs:
            subfolder_path = os.path.join(root, dir_name)
            subfolders.append(subfolder_path)
    logger.info(f"Found {len(subfolders)} subfolders")
    return subfolders

def scan_subfolder(subfolder_path, identifiable_model_ids, model_id_to_entry):
    """Scan a subfolder for actual contents, identifying model names and file paths."""
    logger.info(f"Scanning subfolder: {subfolder_path}")
    print(f"Scanning subfolder: {subfolder_path}", flush=True)
    
    actual_contents = defaultdict(list)
    files = os.listdir(subfolder_path)
    logger.debug(f"Found {len(files)} files in {subfolder_path}")
    
    for file in files:
        file_path = os.path.join(subfolder_path, file)
        if os.path.isfile(file_path):
            base_name, ext = os.path.splitext(file)
            ext = ext.lower()
            if ext in archive_extensions or ext in image_extensions:
                model_id_match = re.search(sky_regex, base_name)
                if model_id_match:
                    model_id = model_id_match.group(1)
                    actual_contents[model_id].append((file, ext, file_path))
                    logger.debug(f"Found file for model_id {model_id}: {file} ({ext}) at {file_path}")
    
    new_identifiable_models = []
    new_unrecognized_models = set()
    
    for model_id, files in actual_contents.items():
        archive_file = None
        image_file = None
        archive_path = None
        image_path = None
        for file_name, ext, file_path in files:
            if ext in archive_extensions:
                archive_file = file_name
                archive_path = file_path
            elif ext in image_extensions:
                image_file = file_name
                image_path = file_path
        
        if archive_file and image_file:
            logger.debug(f"Processing model {model_id} with archive {archive_file} and image {image_file}")
            if model_id in identifiable_model_ids:
                logger.debug(f"Skipping metadata read for known model {model_id}")
                if model_id in model_id_to_entry:
                    model_id_to_entry[model_id]["archive_ext"] = os.path.splitext(archive_file)[1]
                    model_id_to_entry[model_id]["archive_path"] = archive_path
                    model_id_to_entry[model_id]["image_path"] = image_path
                    logger.debug(f"Updated archive extension for {model_id}: {model_id_to_entry[model_id]['archive_ext']}")
                    new_identifiable_models.append(model_id_to_entry[model_id])
                continue
            image_path_full = os.path.join(subfolder_path, image_file)
            logger.info(f"Reading metadata for new model {model_id} from {image_path_full}")
            result, is_pro, extracted_model_id = read_xmp_and_exif_data(image_path_full)
            if result and extracted_model_id and extracted_model_id == model_id:
                desc_parts = [part.strip() for part in result.split("|")]
                if len(desc_parts) >= 3:
                    model_name = desc_parts[0]
                    subcategory = desc_parts[-2]
                    category = desc_parts[-1]
                    entry = {
                        "model_id": model_id,
                        "model_name": model_name,
                        "subcategory": subcategory,
                        "category": category,
                        "is_pro": is_pro,
                        "line": result,
                        "archive_ext": os.path.splitext(archive_file)[1],
                        "archive_path": archive_path,
                        "image_path": image_path
                    }
                    new_identifiable_models.append(entry)
                    model_id_to_entry[model_id] = entry
                    logger.info(f"Added new identifiable model: {model_id} ({model_name})")
                    print(f"Added new identifiable model: {model_id} from {archive_file}", flush=True)
                else:
                    new_unrecognized_models.add(archive_file)
                    logger.info(f"Marked as unrecognized: {archive_file}")
            else:
                new_unrecognized_models.add(archive_file)
                logger.info(f"Marked as unrecognized: {archive_file}")
        elif archive_file:
            new_unrecognized_models.add(archive_file + " (no accompanying image)")
            logger.info(f"Marked as unrecognized (no image): {archive_file}")
    
    logger.debug(f"Returning {len(new_identifiable_models)} identifiable models from {subfolder_path}")
    return new_identifiable_models, new_unrecognized_models


def write_report(output_file, paths_file, all_identifiable_models, all_unrecognized_models, folder_name, metadata_read_count):
    """Write the report with identifiable models and file paths in separate files, sorted numerically by model_id prefix."""
    logger.info(f"Writing report to {output_file} and paths to {paths_file}")
    print(f"Writing report to {output_file} and paths to {paths_file}", flush=True)
    
    # Sort models by integer part of model_id (before the dot)
    def get_model_id_number(model):
        try:
            return int(model["model_id"].split(".")[0])
        except ValueError:
            return float('inf')  # Fallback for invalid numeric prefixes

    meta_lines = []
    path_lines = []
    
    for model in sorted(all_identifiable_models, key=get_model_id_number):
        model_id = model["model_id"]
        model_type = "Pro" if model["is_pro"] else "FREE"
        model_desc = model["line"].split(" - ")[1] if " - " in model["line"] else model["model_name"]
        meta_line = f"{model_id: <21} - {model_type: <4} - {model_desc}\n"
        meta_lines.append(meta_line)
        logger.debug(f"Writing identifiable model: {meta_line.strip()}")
        
        # Add file paths to paths section with quotes
        archive_path = model.get("archive_path", "")
        image_path = model.get("image_path", "")
        if archive_path and image_path:
            path_line = f"{model_id}: \"{archive_path}\", \"{image_path}\"\n"
            path_lines.append(path_line)
            logger.debug(f"Writing path entry: {path_line.strip()}")
    
    container_content = "".join(meta_lines)
    content_bytes = container_content.encode("utf-8")
    content_hash = hashlib.sha512(content_bytes).hexdigest()
    logger.info(f"Computed SHA-512 hash for container content: {content_hash}")
    
    try:
        # Write main metadata file
        with open(output_file, "w", encoding="utf-8") as f:
            f.write(f"[{user_uid}]\n")
            f.writelines(meta_lines)
            f.write(f"[/{user_uid}]\n")
            f.write("[hash_container]\n")
            f.write(f"{content_hash}\n")
            f.write("[/hash_container]\n")
        logger.info(f"Report written to {output_file}")
        print(f"Report written to {output_file}", flush=True)
        
        # Write paths file
        with open(paths_file, "w", encoding="utf-8") as f:
            f.write(f"[{user_uid}]\n")
            f.writelines(path_lines)
            f.write(f"[/{user_uid}]\n")
        logger.info(f"Paths written to {paths_file}")
        print(f"Paths written to {paths_file}", flush=True)
    except Exception as e:
        logger.error(f"Error writing report: {str(e)}")
        print(f"Error writing report: {str(e)}", flush=True)


def generate_report(source_folder):
    """Generate a report by comparing supposed and actual folder contents."""
    logger.info(f"Starting report generation for source folder: {source_folder}")
    if not os.path.isdir(source_folder):
        logger.error(f"Invalid directory: {source_folder}")
        print(f"Error: {source_folder} is not a valid directory.", flush=True)
        return

    folder_name = os.path.basename(source_folder)
    parent_folder = os.path.dirname(source_folder)
    output_file = os.path.join(parent_folder, f"{folder_name}.txt")
    paths_file = os.path.join(parent_folder, f"{folder_name}.paths")

    supposed_contents, model_id_to_entry, identifiable_model_ids, unrecognized_models = [], {}, set(), set()

    if verify_existing_report(output_file, paths_file):
        supposed_contents, model_id_to_entry, identifiable_model_ids, unrecognized_models = parse_supposed_contents(output_file, paths_file)
        logger.info(f"Loaded {len(supposed_contents)} entries from existing report")
    else:
        logger.info(f"Report at {output_file} failed verification or is invalid. Starting fresh.")

    logger.debug(f"Initial identifiable model IDs: {identifiable_model_ids}")

    subfolders = get_subfolders(source_folder)

    all_identifiable_models = []
    all_unrecognized_models = set(unrecognized_models)
    current_model_ids = set()

    for subfolder in subfolders:
        new_identifiable, new_unrecognized = scan_subfolder(subfolder, identifiable_model_ids, model_id_to_entry)
        for model in new_identifiable:
            current_model_ids.add(model["model_id"])
            if model["model_id"] not in [m["model_id"] for m in all_identifiable_models]:
                all_identifiable_models.append(model)
                logger.debug(f"Included model in report: {model['model_id']}")
        all_unrecognized_models.update(new_unrecognized)

    logger.debug(f"Current model IDs found in folder: {current_model_ids}")

    for model in supposed_contents:
        if model["model_id"] in current_model_ids:
            if model["model_id"] not in [m["model_id"] for m in all_identifiable_models]:
                all_identifiable_models.append(model)
                logger.debug(f"Retained existing model: {model['model_id']}")
        else:
            logger.info(f"Removed outdated model {model['model_id']} (not found in subfolders)")
            print(f"Removed outdated model {model['model_id']} (not found in subfolders)", flush=True)

    logger.debug(f"Final identifiable models: {[m['model_id'] for m in all_identifiable_models]}")

    write_report(output_file, paths_file, all_identifiable_models, all_unrecognized_models, folder_name, metadata_read_count)
    logger.info(f"Report generation complete: {output_file} with {len(all_identifiable_models)} identifiable models")
    print(f"Report generation complete: {output_file} with {len(all_identifiable_models)} identifiable models, metadata read count: {metadata_read_count}", flush=True)
    if len(supposed_contents) > len(all_identifiable_models):
        removed_count = len(supposed_contents) - len(all_identifiable_models)
        logger.info(f"Removed {removed_count} outdated models from previous report")
        print(f"Removed {removed_count} outdated models from previous report", flush=True)

def main():
    global metadata_read_count
    logger.info(f"Starting session")
    logger.info(f"Metadata read count at session start: {metadata_read_count}")

    source_folder = load_config()
    if len(sys.argv) > 1:
        source_folder = sys.argv[1].strip()
        if not os.path.isdir(source_folder):
            logger.error(f"Invalid source folder provided via command line: {source_folder}")
            print(f"Error: {source_folder} is not a valid directory.", flush=True)
            sys.exit(1)
        logger.info(f"Using source folder from command line: {source_folder}")
    elif source_folder:
        logger.info(f"Using source folder from sssuite.cfg: {source_folder}")
    else:
        logger.error("No valid source folder provided")
        print("Error: No valid source folder provided. Specify a folder path via command line (e.g., python __lister.py L:\\path\\to\\folder) or configure a valid 3dsky_folder in sssuite.cfg.", flush=True)
        sys.exit(1)

    generate_report(source_folder)
    logger.info(f"Metadata read count at session end: {metadata_read_count}")
    logger.info("Script finished")

if __name__ == "__main__":
    main()

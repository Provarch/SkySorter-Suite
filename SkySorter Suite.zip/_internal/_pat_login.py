# Patreon User Login – Updates ssssuite.cfg + Live banner + Wipe/Rebuild + -r flag + Webhook Query (Dec 2025)
# Sends webhook fields: pat_name, pat_uid, pat_created, dis_uid (optional), alias (optional; from ssssuite.cfg)

import webbrowser
import requests
from http.server import BaseHTTPRequestHandler, HTTPServer
from urllib.parse import parse_qs, urlparse
import json
import os
import html
import threading
import time
import argparse

CLIENT_ID = "B6jsd3w17gKHU4ksvhAMNQOgbguJkYpbhM02yh1axKDrzya1QaVzaKiKOa7-yUic"
PORT = 57431
REDIRECT_URI = f"http://localhost:{PORT}"

auth_url = (
    "https://www.patreon.com/oauth2/authorize"
    f"?response_type=code&client_id={CLIENT_ID}&redirect_uri={REDIRECT_URI}&scope=identity"
)

# Webhook settings
WEBHOOK_URL = "https://discord.com/api/webhooks/1380331430541791293/73VRLImYmigOPMFhkv4W9lXlo8Y98yRwM--APTN1iXnPYTN3Nf_u4D0mi84yvd8lum3Q"
WEBHOOK_USERNAME = "Provarch"

# Utilized Patreon keys in ssssuite.cfg (wipe + rebuild on enrollment / -r)
UTIL_KEYS = ["patreon_user_id", "pat_name", "pat_vanity", "pat_created", "dis_uid"]

# Shared state between server thread and main thread
STATE = {
    "code": None,
    "status": "waiting",  # waiting | processing | ok | warn | err
    "message": "Waiting for Patreon authorization...",
    "user_id": None,
    "pat_name": None,
}
STATE_LOCK = threading.Lock()
CODE_EVENT = threading.Event()


def parse_args():
    parser = argparse.ArgumentParser(description="Patreon user login and config updater (sssuite.cfg)")
    parser.add_argument(
        "-r", "--rebuild",
        action="store_true",
        help="Force rebuild of Patreon fields, ignoring existing patreon_user_id",
    )
    return parser.parse_args()


def is_meaningful(v) -> bool:
    if v is None:
        return False
    if isinstance(v, str) and v.strip() == "":
        return False
    return True


def simplify_iso(ts: str | None) -> str | None:
    """
    Normalize an ISO timestamp by removing fractional seconds
    and timezone information.
    """
    if not ts:
        return None
    ts = ts.split(".", 1)[0]
    ts = ts.split("+", 1)[0]
    return ts


def load_cfg(cfg_path: str) -> dict:
    if not os.path.exists(cfg_path):
        return {}
    with open(cfg_path, "r", encoding="utf-8") as f:
        data = json.load(f)
    if not isinstance(data, dict):
        raise RuntimeError(f"sssuite.cfg must be a JSON object (dict). Got: {type(data)}")
    return data


def save_cfg(cfg_path: str, cfg: dict) -> None:
    with open(cfg_path, "w", encoding="utf-8") as f:
        json.dump(cfg, f, ensure_ascii=False, indent=4)


def banner_page(title: str, message: str, tone: str = "info", live: bool = False) -> bytes:
    """
    tone: ok | warn | err | info
    live=True adds polling JS to fetch /status and update the card.
    """
    styles = {
        "ok": ("#0f5132", "#d1e7dd", "#badbcc"),
        "warn": ("#664d03", "#fff3cd", "#ffecb5"),
        "err": ("#842029", "#f8d7da", "#f5c2c7"),
        "info": ("#084298", "#cfe2ff", "#b6d4fe"),
    }
    fg, bg, border = styles.get(tone, styles["info"])
    title_e = html.escape(title)
    message_e = html.escape(message)

    live_js = ""
    if live:
        live_js = """
<script>
async function poll(){
  try{
    const r = await fetch('/status', {cache:'no-store'});
    const s = await r.json();

    const cardTitle = document.getElementById('t');
    const cardMsg = document.getElementById('m');

    if(s.status === 'processing'){
      cardTitle.textContent = '⏳ Processing Patreon profile...';
      cardMsg.textContent = s.message || 'Working...';
      setTimeout(poll, 800);
      return;
    }

    if(s.status === 'ok'){
      cardTitle.textContent = '✅ Query sent';
      cardMsg.textContent = `Sent: ${s.pat_name} (${s.user_id})`;
      return;
    }

    if(s.status === 'warn'){
      cardTitle.textContent = '⚠️ Authorization cancelled';
      cardMsg.textContent = s.message || 'Cancelled.';
      return;
    }

    if(s.status === 'err'){
      cardTitle.textContent = '❌ Failed';
      cardMsg.textContent = s.message || 'Failed.';
      return;
    }

    setTimeout(poll, 800);
  }catch(e){
    setTimeout(poll, 1200);
  }
}
poll();
</script>
"""

    page = f"""<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Patreon Login</title>
  <style>
    body {{
      margin: 0; padding: 0;
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Arial, sans-serif;
      background: #0b0f19;
      color: #e7e7e7;
      display: grid;
      place-items: center;
      height: 100vh;
    }}
    .card {{
      width: min(720px, 92vw);
      background: {bg};
      border: 1px solid {border};
      border-radius: 14px;
      padding: 22px 22px 18px;
      box-shadow: 0 10px 35px rgba(0,0,0,.35);
    }}
    .title {{
      margin: 0 0 8px;
      font-size: 18px;
      font-weight: 700;
      color: {fg};
    }}
    .msg {{
      margin: 0;
      font-size: 14px;
      line-height: 1.45;
      color: {fg};
      word-break: break-word;
    }}
    .sub {{
      margin-top: 14px;
      font-size: 12px;
      color: rgba(0,0,0,.55);
    }}
    .kbd {{
      font-family: ui-monospace, SFMono-Regular, Menlo, Consolas, monospace;
      padding: 2px 6px;
      border-radius: 6px;
      border: 1px solid rgba(0,0,0,.15);
      background: rgba(255,255,255,.45);
    }}
  </style>
</head>
<body>
  <div class="card">
    <p class="title" id="t">{title_e}</p>
    <p class="msg" id="m">{message_e}</p>
    <div class="sub">You can close this tab anytime, or press <span class="kbd">Ctrl</span>+<span class="kbd">W</span>.</div>
  </div>
  {live_js}
</body>
</html>"""
    return page.encode("utf-8")


def send_webhook_query(pat_name: str, pat_uid: str, pat_created: str, dis_uid: str | None, alias: str | None) -> bool:
    """
    Sends a Discord webhook query message with an embed.
    Includes 'alias' only if meaningful (alias is your custom alias, read from ssssuite.cfg).
    """
    if not is_meaningful(WEBHOOK_URL):
        print("ℹ️ WEBHOOK_URL empty; skipping webhook.")
        return False

    fields = [
        {"name": "pat_name", "value": str(pat_name), "inline": True},
        {"name": "pat_uid", "value": str(pat_uid), "inline": True},
        {"name": "pat_created", "value": str(pat_created), "inline": False},
    ]

    if is_meaningful(dis_uid):
        fields.append({"name": "dis_uid", "value": str(dis_uid), "inline": False})

    if is_meaningful(alias):
        fields.append({"name": "alias", "value": str(alias), "inline": False})

    payload = {
        "username": WEBHOOK_USERNAME,
        "content": "🔍 Patreon login query received",
        "embeds": [
            {
                "title": "Patreon Login Query",
                "color": 16753920,
                "fields": fields,
                "footer": {"text": "event: patreon_login_query"},
            }
        ],
    }

    try:
        r = requests.post(WEBHOOK_URL, json=payload, timeout=15)
        if r.status_code == 204:
            print("✅ Webhook query sent.")
            return True
        print(f"❌ Webhook failed: {r.status_code} - {r.text}")
        return False
    except Exception as e:
        print(f"❌ Webhook error: {e}")
        return False


class Handler(BaseHTTPRequestHandler):
    def do_GET(self):
        path = urlparse(self.path).path
        query = urlparse(self.path).query
        params = parse_qs(query)

        if path == "/status":
            with STATE_LOCK:
                payload = {
                    "status": STATE["status"],
                    "message": STATE["message"],
                    "user_id": STATE["user_id"],
                    "pat_name": STATE["pat_name"],
                }
            body = json.dumps(payload).encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            self.wfile.write(body)
            return

        if "code" in params:
            got_code = params["code"][0]
            with STATE_LOCK:
                STATE["code"] = got_code
                STATE["status"] = "processing"
                STATE["message"] = "Authorization received. Fetching your Patreon profile..."
            CODE_EVENT.set()

            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            self.wfile.write(
                banner_page(
                    "⏳ Processing Patreon profile...",
                    "Please wait… this page will update automatically.",
                    tone="info",
                    live=True,
                )
            )
            return

        if "error" in params:
            err = params.get("error", ["unknown_error"])[0]
            desc = params.get("error_description", [""])[0]
            with STATE_LOCK:
                STATE["status"] = "warn"
                STATE["message"] = (f"{err}. {desc}").strip()
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.end_headers()
            self.wfile.write(banner_page("⚠️ Authorization cancelled", STATE["message"], tone="warn", live=False))
            return

        self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.end_headers()
        self.wfile.write(banner_page("Waiting…", "Please return to Patreon to authorize.", tone="info", live=True))

    def log_message(self, format, *args):
        return


def main():
    # Clean state (important if run multiple times in same process)
    CODE_EVENT.clear()
    with STATE_LOCK:
        STATE["code"] = None
        STATE["status"] = "waiting"
        STATE["message"] = "Waiting for Patreon authorization..."
        STATE["user_id"] = None
        STATE["pat_name"] = None

    args = parse_args()

    script_dir = os.path.dirname(os.path.abspath(__file__))
    cfg_path = os.path.join(script_dir, "sssuite.cfg")

    cfg = load_cfg(cfg_path)

    # Read your custom alias from cfg (NOT Patreon vanity)
    cfg_alias = cfg.get("alias")
    if not is_meaningful(cfg_alias):
        cfg_alias = None

    # ONLY check patreon_user_id unless forced rebuild
    if not args.rebuild and is_meaningful(cfg.get("patreon_user_id")):
        print("✅ ssssuite.cfg already has patreon_user_id. Skipping Patreon login.")
        print(f"CFG: {cfg_path}")
        print("patreon_user_id:", cfg.get("patreon_user_id"))
        return

    if args.rebuild:
        print("🔁 Rebuild flag detected (-r). Forcing Patreon re-sync (ignoring existing patreon_user_id).")

    httpd = HTTPServer(("localhost", PORT), Handler)
    server_thread = threading.Thread(target=httpd.serve_forever, daemon=True)
    server_thread.start()

    print("Opening Patreon login in your browser...")
    webbrowser.open(auth_url)
    print("Waiting for you to log in and authorize...")

    if not CODE_EVENT.wait(timeout=180):
        with STATE_LOCK:
            STATE["status"] = "err"
            STATE["message"] = "Timed out waiting for Patreon authorization."
        print("❌ Timed out waiting for authorization.")
        httpd.shutdown()
        return

    with STATE_LOCK:
        oauth_code = STATE["code"]

    # Exchange code for token
    try:
        token_response = requests.post(
            "https://www.patreon.com/api/oauth2/token",
            data={
                "code": oauth_code,
                "grant_type": "authorization_code",
                "client_id": CLIENT_ID,
                "redirect_uri": REDIRECT_URI,
            },
            timeout=30,
        )
        token_response.raise_for_status()
        token_json = token_response.json()
        access_token = token_json.get("access_token")
        if not access_token:
            raise RuntimeError("No access_token returned from token exchange.")
    except Exception as e:
        with STATE_LOCK:
            STATE["status"] = "err"
            STATE["message"] = f"Token exchange failed: {e}"
        print("❌ Token exchange failed:", e)
        time.sleep(2.0)
        httpd.shutdown()
        return

    # Fetch identity + wipe/rebuild utilized cfg fields
    try:
        fields_param = "fields[user]=created,full_name,vanity,social_connections"
        user_url = f"https://www.patreon.com/api/oauth2/v2/identity?{fields_param}"

        r = requests.get(user_url, headers={"Authorization": f"Bearer {access_token}"}, timeout=30)
        r.raise_for_status()
        user_response = r.json()

        user_data = user_response.get("data", {}) or {}
        attrs = user_data.get("attributes", {}) or {}

        patreon_user_id = user_data.get("id")
        pat_created = simplify_iso(attrs.get("created"))
        pat_name = attrs.get("full_name")
        pat_vanity = attrs.get("vanity")

        social = attrs.get("social_connections") or {}
        discord_obj = social.get("discord") or {}
        dis_uid = discord_obj.get("user_id")

        with STATE_LOCK:
            STATE["user_id"] = patreon_user_id
            STATE["pat_name"] = pat_name
            STATE["status"] = "ok"
            STATE["message"] = "Query sent."

        # Wipe utilized keys (true rebuild)
        for k in UTIL_KEYS:
            cfg.pop(k, None)

        # Write only meaningful values (do NOT write null/empty)
        updates = {
            "patreon_user_id": patreon_user_id,
            "pat_name": pat_name,
            "pat_vanity": pat_vanity,
            "pat_created": pat_created,
            "dis_uid": dis_uid,
        }
        for k, v in updates.items():
            if is_meaningful(v):
                cfg[k] = v

        save_cfg(cfg_path, cfg)

        # Send webhook query (include alias if exists)
        if is_meaningful(patreon_user_id) and is_meaningful(pat_created) and is_meaningful(pat_name):
            send_webhook_query(
                pat_name=str(pat_name),
                pat_uid=str(patreon_user_id),
                pat_created=str(pat_created),
                dis_uid=str(dis_uid) if is_meaningful(dis_uid) else None,
                alias=str(cfg_alias) if is_meaningful(cfg_alias) else None,
            )
        else:
            print("ℹ️ Skipping webhook: missing one of patreon_user_id / pat_created / pat_name")

        print("\n=== Full Patreon Identity Response ===")
        print(json.dumps(user_response, indent=2))

        print("\n✅ Updated ssssuite.cfg:", cfg_path)
        print("Rebuilt fields (written if available):")
        for k in updates.keys():
            if is_meaningful(cfg.get(k)):
                print(f"  {k}: {cfg.get(k)}")

    except Exception as e:
        with STATE_LOCK:
            STATE["status"] = "err"
            STATE["message"] = f"Identity fetch failed: {e}"
        print("❌ Identity fetch failed:", e)
    finally:
        time.sleep(2.0)
        httpd.shutdown()


if __name__ == "__main__":
    main()

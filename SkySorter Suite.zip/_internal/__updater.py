import argparse
import json
import os
import shutil
import subprocess
import sys
import time
import zipfile
from pathlib import Path

try:
    import psutil
except Exception:
    psutil = None


def log(msg: str) -> None:
    print(f"[updater] {msg}", flush=True)


def read_curr_ver(curr_ver_path: Path) -> str:
    try:
        data = json.loads(curr_ver_path.read_text(encoding="utf-8").strip())
        return str(data.get("curr_ver", "")).strip() or "0"
    except Exception:
        return "0"


def write_curr_ver(curr_ver_path: Path, ver: str) -> None:
    curr_ver_path.write_text(json.dumps({"curr_ver": str(ver)}, ensure_ascii=False, indent=2), encoding="utf-8")


def terminate_pid(pid: int, timeout: float = 6.0) -> None:
    if pid <= 0:
        return

    if psutil is None:
        try:
            subprocess.run(["taskkill", "/PID", str(pid), "/T", "/F"], check=False, capture_output=True, text=True)
            log(f"Terminate requested via taskkill: PID {pid}")
        except Exception as e:
            log(f"Failed to taskkill PID {pid}: {e}")
        return

    try:
        p = psutil.Process(pid)
    except Exception:
        log(f"UI PID not found: {pid}")
        return

    try:
        name = p.name()
    except Exception:
        name = "<?>"

    log(f"Terminating UI PID {pid} ({name}) ...")
    try:
        p.terminate()
        try:
            p.wait(timeout=timeout)
            log(f"UI PID {pid} exited.")
            return
        except Exception:
            pass

        log(f"UI PID {pid} still alive; killing...")
        p.kill()
        try:
            p.wait(timeout=timeout)
        except Exception:
            pass
        log(f"UI PID {pid} killed.")
    except Exception as e:
        log(f"Failed to terminate UI PID {pid}: {e}")


def extract_zip(zip_path: Path, target_dir: Path) -> None:
    log(f"Extracting: {zip_path.name}")
    log(f"Target dir : {target_dir}")

    with zipfile.ZipFile(zip_path, "r") as zf:
        infos = zf.infolist()
        total = len(infos)
        log(f"Zip entries: {total}")

        temp_dir = target_dir / "__upd_tmp_extract"
        if temp_dir.exists():
            shutil.rmtree(temp_dir, ignore_errors=True)
        temp_dir.mkdir(parents=True, exist_ok=True)

        for i, info in enumerate(infos, start=1):
            zf.extract(info, path=temp_dir)

            if total > 0 and (i == total or i % max(1, total // 10) == 0):
                pct = int(round((i / total) * 100))
                log(f"Extract progress: {pct}% ({i}/{total})")

        for item in temp_dir.iterdir():
            dest = target_dir / item.name
            if item.is_dir():
                shutil.copytree(item, dest, dirs_exist_ok=True)
            else:
                shutil.copy2(item, dest)

        shutil.rmtree(temp_dir, ignore_errors=True)

    log("Extraction complete.")


def relaunch_ui(install_root: Path) -> None:
    ui_path = install_root / "_internal" / "UI.pyw"
    if not ui_path.exists():
        log(f"ERROR: UI.pyw not found at: {ui_path}")
        return

    log("Relaunching UI.pyw ...")

    creationflags = 0
    if os.name == "nt":
        creationflags = subprocess.DETACHED_PROCESS | subprocess.CREATE_NEW_PROCESS_GROUP

    try:
        subprocess.Popen(
            [sys.executable, str(ui_path)],
            cwd=str(ui_path.parent),
            creationflags=creationflags,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            close_fds=True,
        )
        log("UI relaunched.")
    except Exception as e:
        log(f"Failed to relaunch UI: {e}")


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--ui-pid", type=int, default=0)
    ap.add_argument("--requested-ver", type=str, default="")
    ap.add_argument("--zip", type=str, default="")
    ap.add_argument("--pause", type=float, default=0.0)
    args = ap.parse_args()

    script_dir = Path(__file__).resolve().parent
    install_root = script_dir.parent
    curr_ver_path = script_dir / "curr.ver"

    curr_ver = read_curr_ver(curr_ver_path)
    log(f"Current version: {curr_ver}")
    if args.requested_ver:
        log(f"Requested version: {args.requested_ver}")

    if args.zip:
        zip_path = Path(args.zip).expanduser().resolve()
    else:
        zip_path = script_dir / "SkySorter Suite.zip"

    if not zip_path.exists():
        log(f"ERROR: Zip not found: {zip_path}")
        return 2

    if args.ui_pid:
        terminate_pid(args.ui_pid)
    else:
        log("WARNING: --ui-pid not provided. (No process will be terminated.)")

    time.sleep(0.25)

    try:
        extract_zip(zip_path, install_root)
    except Exception as e:
        log(f"ERROR during extraction: {e}")
        return 3

    new_ver = args.requested_ver.strip() if args.requested_ver.strip() else curr_ver
    if new_ver and new_ver != curr_ver:
        try:
            write_curr_ver(curr_ver_path, new_ver)
            log(f"Wrote curr.ver -> {new_ver}")
        except Exception as e:
            log(f"WARNING: Failed writing curr.ver: {e}")

    relaunch_ui(install_root)

    if args.pause and args.pause > 0:
        log(f"Pausing {args.pause:.1f}s before exit...")
        time.sleep(args.pause)

    log("Done.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

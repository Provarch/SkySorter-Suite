import os
import sys
import json
import time
import zipfile
import subprocess
import pathlib
import psutil
import traceback
from datetime import datetime

DEFAULT_ZIP_NAME = "SkySorter Suite.zip"
CLOSE_DELAY_SECONDS = 1.0
HEARTBEAT_SECONDS = 2.0

# ---------------- logging (file only, overwrite each run) ----------------
def _log_path() -> str:
    return os.path.join(os.path.dirname(os.path.abspath(__file__)), "updater.log")

def _truncate_log():
    try:
        with open(_log_path(), "w", encoding="utf-8") as f:
            f.write("")  # wipe
    except Exception:
        pass

def log(msg: str):
    ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    line = f"[{ts}] {msg}"
    try:
        with open(_log_path(), "a", encoding="utf-8") as f:
            f.write(line + "\n")
    except Exception:
        pass

def log_exc(prefix: str):
    tb = traceback.format_exc()
    log(prefix)
    for ln in tb.splitlines():
        log("  " + ln)

# ---------------- version file ----------------
def _curr_ver_path():
    return os.path.join(os.path.dirname(os.path.abspath(__file__)), "curr.ver")

def read_current_version() -> str:
    try:
        with open(_curr_ver_path(), "r", encoding="utf-8") as f:
            data = json.load(f)
            return str(data.get("curr_ver", "0.0")).strip()
    except Exception:
        return "0.0"

def write_current_version(new_ver: str) -> None:
    try:
        with open(_curr_ver_path(), "w", encoding="utf-8") as f:
            json.dump({"curr_ver": str(new_ver).strip()}, f, indent=2)
        log(f"Wrote curr.ver -> {new_ver}")
    except Exception as e:
        log(f"WARNING: Failed to write curr.ver: {e}")

def version_compare(v1: str, v2: str) -> int:
    try:
        a = [int(x) for x in str(v1).split(".") if x != ""]
        b = [int(x) for x in str(v2).split(".") if x != ""]
    except Exception:
        return 0
    n = max(len(a), len(b))
    a += [0] * (n - len(a))
    b += [0] * (n - len(b))
    for x, y in zip(a, b):
        if x > y:
            return 1
        if x < y:
            return -1
    return 0

# ---------------- install target ----------------
def get_install_zip_upd() -> str:
    # __updater.py is in _internal; extract target is parent
    script_dir = os.path.dirname(os.path.abspath(__file__))
    return str(pathlib.Path(script_dir).parent)

# ---------------- arg parsing ----------------
def parse_arg_value(flag: str):
    if flag in sys.argv:
        i = sys.argv.index(flag)
        if i + 1 < len(sys.argv):
            return sys.argv[i + 1]
    return None

# ---------------- process control ----------------
def kill_ui_pid(ui_pid: int) -> bool:
    try:
        p = psutil.Process(ui_pid)
        log(f"Terminating UI PID {ui_pid} ...")
        p.terminate()
        try:
            p.wait(timeout=5)
        except psutil.TimeoutExpired:
            log("UI did not exit in 5s, killing...")
            p.kill()
            p.wait(timeout=5)
        log("UI terminated.")
        return True
    except Exception as e:
        log(f"WARNING: Failed to terminate PID {ui_pid}: {e}")
        return False

# ---------------- extraction ----------------
def unzip_update(zip_path: str, target_dir: str) -> bool:
    if not zip_path:
        log("ERROR: zip_path is empty")
        return False
    if not os.path.exists(zip_path):
        log(f"ERROR: Zip not found: {zip_path}")
        return False

    log(f"Extracting: {os.path.basename(zip_path)}")
    log(f"Zip path : {zip_path}")
    log(f"Target   : {target_dir}")

    last_beat = time.time()
    current_member = None
    current_index = 0
    total = 0

    try:
        with zipfile.ZipFile(zip_path, "r") as z:
            infos = z.infolist()
            total = len(infos)
            log(f"Zip entries: {total}")

            for i, info in enumerate(infos, start=1):
                current_index = i
                current_member = info.filename

                log(f"Extracting entry {i}/{total}: {current_member} (size={info.file_size})")

                now = time.time()
                if now - last_beat >= HEARTBEAT_SECONDS:
                    log(f"Heartbeat: still extracting... (at {i}/{total})")
                    last_beat = now

                if current_member.endswith("/"):
                    os.makedirs(os.path.join(target_dir, current_member), exist_ok=True)
                else:
                    dest_path = os.path.join(target_dir, current_member)
                    os.makedirs(os.path.dirname(dest_path), exist_ok=True)

                    # stream copy (avoid reading entire file into memory)
                    with z.open(info) as src, open(dest_path, "wb") as dst:
                        while True:
                            chunk = src.read(1024 * 1024)  # 1MB chunks
                            if not chunk:
                                break
                            dst.write(chunk)

                            now = time.time()
                            if now - last_beat >= HEARTBEAT_SECONDS:
                                log(f"Heartbeat: writing {current_member} ...")
                                last_beat = now

            log("Extraction complete.")
            return True

    except Exception:
        log_exc(f"ERROR: Extraction failed (member {current_index}/{total}: {current_member}):")
        return False

# ---------------- relaunch ----------------
def relaunch_ui(install_zip_upd: str) -> bool:
    ui_path = os.path.join(install_zip_upd, "_internal", "UI.pyw")
    log(f"UI path  : {ui_path}")

    if not os.path.exists(ui_path):
        log(f"ERROR: UI.pyw not found at: {ui_path}")
        return False

    log("Relaunching UI.pyw ...")
    try:
        subprocess.Popen(
            [sys.executable, ui_path],
            creationflags=subprocess.DETACHED_PROCESS,
            cwd=os.path.dirname(ui_path),
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            close_fds=True,
        )
        log("UI relaunched.")
        return True
    except Exception:
        log_exc("ERROR: Failed to relaunch UI:")
        return False

def main():
    _truncate_log()

    log("=" * 70)
    log("Updater starting")
    log(f"log file : {_log_path()}")
    log(f"argv      : {sys.argv}")

    cwd = os.path.dirname(os.path.abspath(__file__))
    install_zip_upd = get_install_zip_upd()
    log(f"cwd       : {cwd}")
    log(f"target dir: {install_zip_upd}")

    # Args: __updater.py [zip_path] [new_version] --ui-pid PID
    zip_path = sys.argv[1] if len(sys.argv) >= 2 and not sys.argv[1].startswith("--") else ""
    new_version = sys.argv[2].strip() if len(sys.argv) >= 3 and not sys.argv[2].startswith("--") else ""

    ui_pid_val = parse_arg_value("--ui-pid")
    ui_pid = int(ui_pid_val) if ui_pid_val and ui_pid_val.isdigit() else None

    if not zip_path:
        candidate = os.path.join(cwd, DEFAULT_ZIP_NAME)
        log(f"zip arg empty; trying default: {candidate}")
        if os.path.exists(candidate):
            zip_path = candidate

    log(f"zip_path   : {zip_path}")
    log(f"new_version: {new_version!r}")
    log(f"ui_pid     : {ui_pid}")

    if not zip_path or not os.path.exists(zip_path):
        log("ERROR: No update zip available. Exiting.")
        return

    curr_ver = read_current_version()
    log(f"curr.ver   : {curr_ver}")

    if new_version:
        cmp = version_compare(new_version, curr_ver)
        log(f"version_compare(new, curr) = {cmp}")
        if cmp <= 0:
            log("Requested version is not newer. Exiting.")
            return
    else:
        log("WARNING: No version provided by caller (will extract anyway).")

    if ui_pid is not None:
        log(f"Closing UI in {CLOSE_DELAY_SECONDS:.1f}s ...")
        time.sleep(CLOSE_DELAY_SECONDS)
        kill_ui_pid(ui_pid)
        time.sleep(0.4)
    else:
        log("WARNING: --ui-pid not provided. UI will not be terminated.")

    ok = unzip_update(zip_path, install_zip_upd)
    log(f"extract ok: {ok}")

    if ok and new_version:
        write_current_version(new_version)

    ui_check = os.path.join(install_zip_upd, "_internal", "UI.pyw")
    log(f"post-extract UI.pyw exists? {os.path.exists(ui_check)}")

    time.sleep(0.5)
    relaunched = relaunch_ui(install_zip_upd)
    log(f"relaunch ok: {relaunched}")

    log("Updater finished")

if __name__ == "__main__":
    try:
        main()
    except Exception:
        _truncate_log()
        log_exc("FATAL: Updater crashed:")
        # still no stdout
        raise

import os
import sys
import json
import time
import zipfile
import subprocess
import pathlib
import psutil

DEFAULT_ZIP_NAME = "SkySorter Suite.zip"
CLOSE_DELAY_SECONDS = 3.0

def log(msg: str):
    print(f"[updater] {msg}", flush=True)

def _curr_ver_path():
    return os.path.join(os.path.dirname(os.path.abspath(__file__)), "curr.ver")

def read_current_version() -> str:
    try:
        with open(_curr_ver_path(), "r", encoding="utf-8") as f:
            data = json.load(f)
            return str(data.get("curr_ver", "0.0")).strip()
    except Exception:
        return "0.0"

def write_current_version(new_ver: str) -> None:
    try:
        with open(_curr_ver_path(), "w", encoding="utf-8") as f:
            json.dump({"curr_ver": str(new_ver).strip()}, f, indent=2)
        log(f"Wrote curr.ver -> {new_ver}")
    except Exception as e:
        log(f"WARNING: Failed to write curr.ver: {e}")

def version_compare(v1: str, v2: str) -> int:
    try:
        a = [int(x) for x in str(v1).split(".") if x != ""]
        b = [int(x) for x in str(v2).split(".") if x != ""]
    except Exception:
        return 0

    n = max(len(a), len(b))
    a += [0] * (n - len(a))
    b += [0] * (n - len(b))

    for x, y in zip(a, b):
        if x > y: return 1
        if x < y: return -1
    return 0

def get_install_zip_upd() -> str:
    script_dir = os.path.dirname(os.path.abspath(__file__))
    return str(pathlib.Path(script_dir).parent)

def parse_arg_value(flag: str):
    if flag in sys.argv:
        i = sys.argv.index(flag)
        if i + 1 < len(sys.argv):
            return sys.argv[i + 1]
    return None

def kill_ui_pid(ui_pid: int) -> bool:
    try:
        p = psutil.Process(ui_pid)
        log(f"Terminating UI PID {ui_pid} ...")
        p.terminate()
        try:
            p.wait(timeout=5)
        except psutil.TimeoutExpired:
            log("UI did not exit in 5s, killing...")
            p.kill()
            p.wait(timeout=5)
        log("UI terminated.")
        return True
    except Exception as e:
        log(f"WARNING: Failed to terminate PID {ui_pid}: {e}")
        return False

def unzip_update(zip_path: str, target_dir: str) -> bool:
    if not zip_path or not os.path.exists(zip_path):
        log(f"ERROR: Zip not found: {zip_path}")
        return False

    log(f"Extracting: {os.path.basename(zip_path)}")
    log(f"Target dir : {target_dir}")

    try:
        with zipfile.ZipFile(zip_path, "r") as z:
            infos = z.infolist()
            total = len(infos)
            log(f"Zip entries: {total}")

            step = max(1, total // 10)

            for i, info in enumerate(infos, start=1):
                member = info.filename

                if member.endswith("/"):
                    os.makedirs(os.path.join(target_dir, member), exist_ok=True)
                else:
                    dest_path = os.path.join(target_dir, member)
                    os.makedirs(os.path.dirname(dest_path), exist_ok=True)
                    with z.open(info) as src, open(dest_path, "wb") as dst:
                        dst.write(src.read())

                if (i % step == 0) or (i == total):
                    pct = int((i / total) * 100) if total else 100
                    log(f"Extract progress: {pct}% ({i}/{total})")

        log("Extraction complete.")
        return True

    except zipfile.BadZipFile as e:
        log(f"ERROR: Bad zip file: {e}")
        return False
    except Exception as e:
        log(f"ERROR: Extraction failed: {e}")
        return False

def relaunch_ui(install_zip_upd: str):
    ui_path = os.path.join(install_zip_upd, "_internal", "UI.pyw")
    if not os.path.exists(ui_path):
        log(f"ERROR: UI.pyw not found: {ui_path}")
        return False

    log("Relaunching UI.pyw ...")
    try:
        subprocess.Popen(
            [sys.executable, ui_path],
            creationflags=subprocess.DETACHED_PROCESS,
            cwd=os.path.dirname(ui_path),
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            close_fds=True
        )
        log("UI relaunched.")
        return True
    except Exception as e:
        log(f"ERROR: Failed to relaunch UI: {e}")
        return False

def main():
    cwd = os.path.dirname(os.path.abspath(__file__))
    install_zip_upd = get_install_zip_upd()

    zip_path = sys.argv[1] if len(sys.argv) >= 2 and not sys.argv[1].startswith("--") else ""
    new_version = sys.argv[2].strip() if len(sys.argv) >= 3 and not sys.argv[2].startswith("--") else ""

    ui_pid_val = parse_arg_value("--ui-pid")
    ui_pid = int(ui_pid_val) if ui_pid_val and ui_pid_val.isdigit() else None

    if not zip_path:
        candidate = os.path.join(cwd, DEFAULT_ZIP_NAME)
        if os.path.exists(candidate):
            zip_path = candidate

    if not zip_path or not os.path.exists(zip_path):
        log("No update zip available. Exiting.")
        return

    curr_ver = read_current_version()
    log(f"Current version: {curr_ver}")

    if new_version:
        log(f"Requested version: {new_version}")
        if version_compare(new_version, curr_ver) <= 0:
            log("Requested version is not newer. Exiting.")
            return
    else:
        log("No version provided by caller (will extract anyway).")

    if ui_pid is not None:
        log(f"Closing UI in {CLOSE_DELAY_SECONDS:.1f}s (copy logs now)...")
        time.sleep(CLOSE_DELAY_SECONDS)
        kill_ui_pid(ui_pid)
        time.sleep(0.4)
    else:
        log("WARNING: --ui-pid not provided. (No process will be terminated.)")

    ok = unzip_update(zip_path, install_zip_upd)
    if ok and new_version:
        write_current_version(new_version)

    time.sleep(0.5)
    relaunch_ui(install_zip_upd)
    log("Done.")

if __name__ == "__main__":
    main()

import requests
import re
import json
import sys
import subprocess
from pathlib import Path
import tkinter as tk
import webbrowser

# ---------------- CONFIG ---------------- #
REPO_API_URL = "https://api.github.com/repos/Provarch/SkySorter-Suite/contents?ref=main"
ZIP_PATTERN = r".*_upd_v([\d.]+)\.zip"
HEADERS = {
    "User-Agent": "Mozilla/5.0",
    "Accept": "application/vnd.github+json"
}
POPUP_OFFSET_X = 0  # Horizontal offset from screen center (pixels)
POPUP_OFFSET_Y = -100  # Vertical offset from screen center (pixels)
# ---------------------------------------- #

# Button style
button_style = {
    "bg": "#000000",  # Pure black
    "fg": "white",
    "font": ("Consolas", 10),
    "bd": 0,
    "relief": "flat",
    "activebackground": "#444444",
    "activeforeground": "white"
}

def show_whats_new_popup(whats_new_content):
    whats_new_popup = tk.Toplevel()
    whats_new_popup.title("What's New")
    whats_new_popup.overrideredirect(True)  # Remove title bar
    whats_new_popup.attributes("-topmost", True)
    whats_new_popup.configure(bg="#000000")
    
    # Center popup on screen with offset
    whats_new_popup.update_idletasks()
    width = 400
    height = 300
    screen_width = whats_new_popup.winfo_screenwidth()
    screen_height = whats_new_popup.winfo_screenheight()
    x = (screen_width - width) // 2 + POPUP_OFFSET_X
    y = (screen_height - height) // 2 + POPUP_OFFSET_Y
    whats_new_popup.geometry(f"{width}x{height}+{x}+{y}")

    # Main frame to hold content
    main_frame = tk.Frame(whats_new_popup, bg="#000000")
    main_frame.pack(fill="both", expand=True, padx=10, pady=10)

    # Top frame for close button
    top_frame = tk.Frame(main_frame, bg="#000000")
    top_frame.pack(fill="x")

    # Close button in top-right
    close_button_top = tk.Button(top_frame, text="X", command=whats_new_popup.destroy, bg="#000000", fg="white",
                                font=("Consolas", 10), bd=0)
    close_button_top.pack(side=tk.RIGHT, padx=5, pady=5)

    # Text area for what's new content with clickable links
    text = tk.Text(main_frame, bg="#000000", fg="white", font=("Consolas", 10), wrap="word")
    text.pack(fill="both", expand=True, pady=(0, 10))

    # Insert content and detect URLs
    text.insert("1.0", whats_new_content)
    url_pattern = r'http[s]?://(?:[a-zA-Z]|[0-9]|[$-_@.&+]|[!*\\(\\),]|(?:%[0-9a-fA-F][0-9a-fA-F]))+'
    for match in re.finditer(url_pattern, whats_new_content):
        start_idx = f"1.0 + {match.start()}c"
        end_idx = f"1.0 + {match.end()}c"
        text.tag_add("link", start_idx, end_idx)
        text.tag_config("link", foreground="blue", underline=True)
        text.tag_bind("link", "<Button-1>", lambda e, url=match.group(): webbrowser.open_new(url))

    text.config(state="disabled")  # Read-only

    # Resize handles for corners
    resize_data = {"x": 0, "y": 0, "resizing": None, "width": width, "height": height}
    HANDLE_SIZE = 10  # Size of the resize handle area

    # Bottom-right resize handle
    br_handle = tk.Frame(whats_new_popup, bg="#444444", width=HANDLE_SIZE, height=HANDLE_SIZE, cursor="size_nw_se")
    br_handle.place(relx=1.0, rely=1.0, anchor="se")

    # Bottom-left resize handle
    bl_handle = tk.Frame(whats_new_popup, bg="#444444", width=HANDLE_SIZE, height=HANDLE_SIZE, cursor="size_ne_sw")
    bl_handle.place(relx=0.0, rely=1.0, anchor="sw")

    # Top-right resize handle
    tr_handle = tk.Frame(whats_new_popup, bg="#444444", width=HANDLE_SIZE, height=HANDLE_SIZE, cursor="size_ne_sw")
    tr_handle.place(relx=1.0, rely=0.0, anchor="ne")

    # Top-left resize handle
    tl_handle = tk.Frame(whats_new_popup, bg="#444444", width=HANDLE_SIZE, height=HANDLE_SIZE, cursor="size_nw_se")
    tl_handle.place(relx=0.0, rely=0.0, anchor="nw")

    def start_resize(event, corner):
        resize_data["x"] = event.x_root
        resize_data["y"] = event.y_root
        resize_data["resizing"] = corner

    def stop_resize(event):
        resize_data["resizing"] = None

    def resize(event):
        if resize_data["resizing"]:
            dx = event.x_root - resize_data["x"]
            dy = event.y_root - resize_data["y"]
            new_width = resize_data["width"]
            new_height = resize_data["height"]
            new_x = whats_new_popup.winfo_x()
            new_y = whats_new_popup.winfo_y()

            if resize_data["resizing"] in ("br", "tr"):
                new_width = max(200, resize_data["width"] + dx)  # Minimum width
            if resize_data["resizing"] in ("bl", "tl"):
                new_width = max(200, resize_data["width"] - dx)
                new_x += dx
            if resize_data["resizing"] in ("br", "bl"):
                new_height = max(150, resize_data["height"] + dy)  # Minimum height
            if resize_data["resizing"] in ("tr", "tl"):
                new_height = max(150, resize_data["height"] - dy)
                new_y += dy

            resize_data["width"] = new_width
            resize_data["height"] = new_height
            resize_data["x"] = event.x_root
            resize_data["y"] = event.y_root
            whats_new_popup.geometry(f"{int(new_width)}x{int(new_height)}+{int(new_x)}+{int(new_y)}")

    # Bind resize events to handles
    br_handle.bind("<Button-1>", lambda e: start_resize(e, "br"))
    br_handle.bind("<ButtonRelease-1>", stop_resize)
    br_handle.bind("<B1-Motion>", resize)

    bl_handle.bind("<Button-1>", lambda e: start_resize(e, "bl"))
    bl_handle.bind("<ButtonRelease-1>", stop_resize)
    bl_handle.bind("<B1-Motion>", resize)

    tr_handle.bind("<Button-1>", lambda e: start_resize(e, "tr"))
    tr_handle.bind("<ButtonRelease-1>", stop_resize)
    tr_handle.bind("<B1-Motion>", resize)

    tl_handle.bind("<Button-1>", lambda e: start_resize(e, "tl"))
    tl_handle.bind("<ButtonRelease-1>", stop_resize)
    tl_handle.bind("<B1-Motion>", resize)

    # Drag functionality
    drag_data = {"x": 0, "y": 0, "dragging": False}

    def start_drag(event):
        drag_data["x"] = event.x
        drag_data["y"] = event.y
        drag_data["dragging"] = True

    def stop_drag(event):
        drag_data["dragging"] = False

    def drag(event):
        if drag_data["dragging"]:
            x = whats_new_popup.winfo_x() + (event.x - drag_data["x"])
            y = whats_new_popup.winfo_y() + (event.y - drag_data["y"])
            whats_new_popup.geometry(f"+{x}+{y}")

    whats_new_popup.bind("<Button-1>", start_drag)
    whats_new_popup.bind("<ButtonRelease-1>", stop_drag)
    whats_new_popup.bind("<B1-Motion>", drag)

def get_current_version(ver_file):
    try:
        with open(ver_file, 'r', encoding='utf-8') as f:
            data = json.load(f)
            return float(data["curr_ver"])
    except Exception as e:
        print(f"Error reading version file: {e}")
        sys.exit(1)

def show_custom_popup(latest_ver, zip_url, local_path, whats_new_content):
    root = tk.Tk()
    root.withdraw()  # Hide root

    popup = tk.Toplevel()
    popup.title("Update Available")
    popup.overrideredirect(True)
    popup.attributes("-topmost", True)
    popup.configure(bg="#000000")

    # Center popup on screen with offset
    popup.update_idletasks()
    width = 300
    height = 120
    screen_width = popup.winfo_screenwidth()
    screen_height = popup.winfo_screenheight()
    x = (screen_width - width) // 2 + POPUP_OFFSET_X
    y = (screen_height - height) // 2 + POPUP_OFFSET_Y
    popup.geometry(f"{width}x{height}+{x}+{y}")

    drag_data = {"x": 0, "y": 0, "dragging": False}

    frame = tk.Frame(popup, bg="#000000")
    frame.grid(row=0, column=0, sticky="nsew")

    # Configure grid to center vertically and horizontally
    popup.grid_rowconfigure(0, weight=1)
    popup.grid_columnconfigure(0, weight=1)
    frame.grid_rowconfigure(0, weight=1)
    frame.grid_rowconfigure(1, weight=1)
    frame.grid_columnconfigure(0, weight=1)

    # Label in the first row, centered horizontally
    label = tk.Label(frame, text=f"Update v{latest_ver} available!", bg="#000000", fg="white",
                     font=("Consolas", 10))
    label.grid(row=0, column=0, pady=(0, 5), sticky="ew")

    # Button frame in the second row, centered horizontally
    btn_frame = tk.Frame(frame, bg="#000000")
    btn_frame.grid(row=1, column=0, pady=(0, 5), sticky="ew")

    # Center buttons within btn_frame using grid with three columns
    btn_frame.grid_columnconfigure(0, weight=1)
    btn_frame.grid_columnconfigure(1, weight=1)
    btn_frame.grid_columnconfigure(2, weight=1)

    def update_action():
        try:
            # Call the downloader script with zip_url and local_path as arguments
            subprocess.run([sys.executable, "__upd_dloader.py", zip_url, str(local_path)], check=True)
            print(f"Download initiated for: {local_path}")
        except subprocess.CalledProcessError as e:
            print(f"Download failed: {e}")
        popup.destroy()
        root.quit()

    def cancel_action():
        print("Update cancelled.")
        popup.destroy()
        root.quit()

    def whats_new_action():
        show_whats_new_popup(whats_new_content)

    tk.Button(btn_frame, text="Update", command=update_action, **button_style).grid(row=0, column=0, padx=5, sticky="e")
    tk.Button(btn_frame, text="What's New", command=whats_new_action, **button_style).grid(row=0, column=1, padx=5)
    tk.Button(btn_frame, text="Cancel", command=cancel_action, **button_style).grid(row=0, column=2, padx=5, sticky="w")

    def start_drag(event):
        drag_data["x"] = event.x
        drag_data["y"] = event.y
        drag_data["dragging"] = True

    def stop_drag(event):
        drag_data["dragging"] = False

    def drag(event):
        if drag_data["dragging"]:
            x = popup.winfo_x() + (event.x - drag_data["x"])
            y = popup.winfo_y() + (event.y - drag_data["y"])
            popup.geometry(f"+{x}+{y}")

    popup.bind("<Button-1>", start_drag)
    popup.bind("<ButtonRelease-1>", stop_drag)
    popup.bind("<B1-Motion>", drag)

    root.mainloop()

def check_for_updates():
    script_dir = Path(__file__).parent
    version_file = script_dir / "curr.ver"
    curr_ver = get_current_version(version_file)

    try:
        response = requests.get(REPO_API_URL, headers=HEADERS, timeout=10)
        response.raise_for_status()
        files = response.json()

        latest_ver = None
        latest_zip_name = None

        for file in files:
            if file['type'] == 'file' and file['name'].endswith('.zip'):
                match = re.match(ZIP_PATTERN, file['name'])
                if match:
                    try:
                        version = float(match.group(1))
                        if latest_ver is None or version > latest_ver:
                            latest_ver = version
                            latest_zip_name = file['name']
                    except ValueError:
                        continue

        if latest_ver is None:
            return

        if latest_ver > curr_ver:
            raw_url = f"https://raw.githubusercontent.com/Provarch/SkySorter-Suite/main/{latest_zip_name}"
            local_path = script_dir / latest_zip_name
            # Dynamically construct the whats_new file URL based on latest_ver
            whats_new_url = f"https://raw.githubusercontent.com/Provarch/SkySorter-Suite/main/whas_new_v{latest_ver}.txt"
            try:
                whats_new_response = requests.get(whats_new_url, timeout=10)
                whats_new_response.raise_for_status()
                whats_new_content = whats_new_response.text
                whats_new_content = re.sub(r'\[whats_new\](.*?)\[/whats_new\]', r'\1', whats_new_content, flags=re.DOTALL).strip()
            except requests.RequestException:
                whats_new_content = "Unable to load What's New information."
            show_custom_popup(latest_ver, raw_url, local_path, whats_new_content)
        else:
            print(f"\nScripts all up to date. (v{curr_ver})", flush=True)

    except Exception:
        return

if __name__ == "__main__":
    check_for_updates()
